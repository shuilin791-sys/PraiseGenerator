import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

main_activity_file = f"{package_path}/MainActivity.java"

with open(main_activity_file, "r", encoding="utf-8") as f:
    m_code = f.read()

# Add needed imports for drawing beautiful card bitmap and preview dialog
imports_to_add = """import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;"""

m_code = m_code.replace("import android.provider.MediaStore;", "import android.provider.MediaStore;\n" + imports_to_add)

# Replace old exportCardAsImage with beautiful card drawing & preview dialog
old_export_method = """    private void exportCardAsImage() {
        if (cardComplimentWrapper == null) return;
        try {
            Bitmap bitmap = Bitmap.createBitmap(cardComplimentWrapper.getWidth(), cardComplimentWrapper.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            cardComplimentWrapper.draw(canvas);

            String title = "PraiseCard_" + System.currentTimeMillis();
            String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, title, "来自夸奖器App的精美卡片");

            if (savedPath != null) {
                Toast.makeText(this, R.string.toast_card_saved, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "美图卡片生成成功！", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "卡片导出失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }"""

new_export_method = """    private void exportCardAsImage() {
        if (currentPraiseItem == null) return;
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            String quoteText = currentPraiseItem.getFormattedText();
            Bitmap cardBitmap = drawBeautifulPraiseCardBitmap(targetName, quoteText);

            if (cardBitmap != null) {
                showImagePreviewDialog(cardBitmap);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "卡片生成失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap drawBeautifulPraiseCardBitmap(String targetName, String quoteText) {
        int width = 1080;
        int height = 1480;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        // 1. Background Gradient
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int startColor = isDark ? Color.parseColor("#090D16") : Color.parseColor("#F1F5F9");
        int midColor = isDark ? Color.parseColor("#111827") : Color.parseColor("#E2E8F0");
        int endColor = isDark ? Color.parseColor("#1E293B") : Color.parseColor("#F8FAFC");
        LinearGradient bgGradient = new LinearGradient(0, 0, width, height, new int[]{startColor, midColor, endColor}, null, Shader.TileMode.CLAMP);
        bgPaint.setShader(bgGradient);
        canvas.drawRect(0, 0, width, height, bgPaint);

        // 2. Glass Card Container
        int cardMargin = 72;
        int cardTop = 180;
        int cardBottom = height - 160;
        RectF cardRect = new RectF(cardMargin, cardTop, width - cardMargin, cardBottom);

        Paint cardBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBgPaint.setStyle(Paint.Style.FILL);
        cardBgPaint.setColor(isDark ? Color.parseColor("#25FFFFFF") : Color.parseColor("#FAFFFFFF"));
        canvas.drawRoundRect(cardRect, 48, 48, cardBgPaint);

        Paint cardBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBorderPaint.setStyle(Paint.Style.STROKE);
        cardBorderPaint.setStrokeWidth(3f);
        cardBorderPaint.setColor(isDark ? Color.parseColor("#475569") : Color.parseColor("#CBD5E1"));
        canvas.drawRoundRect(cardRect, 48, 48, cardBorderPaint);

        // 3. Header Badge
        Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        badgePaint.setColor(Color.parseColor("#007AFF"));
        badgePaint.setTextSize(34f);
        badgePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("✦ 今日赞美 ✦", cardMargin + 60, cardTop + 100, badgePaint);

        // Target Name Display
        Paint namePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        namePaint.setColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        namePaint.setTextSize(56f);
        namePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText(targetName, cardMargin + 60, cardTop + 180, namePaint);

        // 4. Quote Text Layout
        TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        textPaint.setTextSize(44f);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        int maxTextWidth = width - (cardMargin + 60) * 2;
        StaticLayout staticLayout;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            staticLayout = StaticLayout.Builder.obtain(quoteText, 0, quoteText.length(), textPaint, maxTextWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(20f, 1.25f)
                    .build();
        } else {
            staticLayout = new StaticLayout(quoteText, textPaint, maxTextWidth, Layout.Alignment.ALIGN_NORMAL, 1.25f, 20f, false);
        }

        canvas.save();
        canvas.translate(cardMargin + 60, cardTop + 260);
        staticLayout.draw(canvas);
        canvas.restore();

        // 5. Card Footer (Date & Brand Tag)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        String dateStr = sdf.format(new Date());

        Paint footerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        footerPaint.setColor(isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#64748B"));
        footerPaint.setTextSize(32f);
        canvas.drawText(dateStr, cardMargin + 60, cardBottom - 60, footerPaint);

        Paint brandPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        brandPaint.setColor(Color.parseColor("#007AFF"));
        brandPaint.setTextSize(32f);
        brandPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        brandPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("—— 来自「夸奖器」App", width - cardMargin - 60, cardBottom - 60, brandPaint);

        return bitmap;
    }

    private void showImagePreviewDialog(final Bitmap cardBitmap) {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 40, 48, 40);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        // Header
        RelativeLayout headerLayout = new RelativeLayout(this);
        TextView tvTitle = new TextView(this);
        tvTitle.setText("美图卡片预览 🎨");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        headerLayout.addView(tvTitle);
        layout.addView(headerLayout);

        // Image Preview Display
        ImageView imgPreview = new ImageView(this);
        imgPreview.setAdjustViewBounds(true);
        imgPreview.setImageBitmap(cardBitmap);
        
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        imgParams.topMargin = 24;
        imgParams.bottomMargin = 28;
        imgPreview.setLayoutParams(imgParams);
        layout.addView(imgPreview);

        // Action Buttons Row (Save to Gallery & Share)
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnSave = new TextView(this);
        btnSave.setText("保存到相册");
        btnSave.setTextColor(Color.WHITE);
        btnSave.setTextSize(14);
        btnSave.setTypeface(null, android.graphics.Typeface.BOLD);
        btnSave.setGravity(Gravity.CENTER);
        btnSave.setBackgroundResource(R.drawable.bg_glass_button);

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(0, 110, 1f);
        saveParams.rightMargin = 12;
        btnSave.setLayoutParams(saveParams);
        btnRow.addView(btnSave);

        TextView btnShare = new TextView(this);
        btnShare.setText("分享卡片");
        btnShare.setTextColor(Color.parseColor("#007AFF"));
        btnShare.setTextSize(14);
        btnShare.setTypeface(null, android.graphics.Typeface.BOLD);
        btnShare.setGravity(Gravity.CENTER);
        btnShare.setBackgroundResource(R.drawable.bg_glass_button_secondary);

        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, 110, 1f);
        shareParams.leftMargin = 12;
        btnShare.setLayoutParams(shareParams);
        btnRow.addView(btnShare);

        layout.addView(btnRow);

        dialog.setContentView(layout);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.7f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        btnSave.setOnClickListener(v -> {
            try {
                String title = "PraiseCard_" + System.currentTimeMillis();
                String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), cardBitmap, title, "来自夸奖器App的精美卡片");
                if (savedPath != null) {
                    Toast.makeText(MainActivity.this, R.string.toast_card_saved, Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "卡片已保存至相册！", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "保存失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnShare.setOnClickListener(v -> {
            try {
                String title = "PraiseCard_" + System.currentTimeMillis();
                String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), cardBitmap, title, "来自夸奖器App的精美卡片");
                if (savedPath != null) {
                    Uri imageUri = Uri.parse(savedPath);
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("image/*");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                    startActivity(Intent.createChooser(shareIntent, "分享美图卡片"));
                    dialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "分享失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }"""

m_code = m_code.replace(old_export_method, new_export_method)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(m_code)

print("Beautiful Card Image drawing & Preview Dialog implemented cleanly.")
