import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update FavoritesAdapter to use light/dark glass card background if needed
adapter_java = """package com.yangxinning.praise.adapter;

import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.R;
import com.yangxinning.praise.model.PraiseItem;

import java.util.ArrayList;
import java.util.List;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder> {

    public interface OnItemActionListener {
        void onCopy(PraiseItem item);
        void onShare(PraiseItem item);
        void onDelete(PraiseItem item, int position);
    }

    private final List<PraiseItem> itemList;
    private final OnItemActionListener listener;

    public FavoritesAdapter(List<PraiseItem> list, OnItemActionListener listener) {
        this.itemList = (list != null) ? list : new ArrayList<>();
        this.listener = listener;
    }

    public void updateData(List<PraiseItem> newList) {
        this.itemList.clear();
        if (newList != null) {
            this.itemList.addAll(newList);
        }
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (position >= 0 && position < itemList.size()) {
            itemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, itemList.size() - position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_favorite_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PraiseItem item = itemList.get(position);
        holder.tvText.setText(item.getFormattedText());
        holder.tvDate.setText(item.getFormattedDate());

        boolean isDark = (holder.itemView.getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (holder.cardInner != null) {
            holder.cardInner.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);
        }

        holder.btnCopy.setOnClickListener(v -> {
            if (listener != null) listener.onCopy(item);
        });

        holder.btnShare.setOnClickListener(v -> {
            if (listener != null) listener.onShare(item);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(item, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View cardInner;
        TextView tvText;
        TextView tvDate;
        ImageView btnCopy;
        ImageView btnShare;
        ImageView btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardInner = itemView.findViewById(R.id.card_item_inner);
            tvText = itemView.findViewById(R.id.tv_item_text);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            btnCopy = itemView.findViewById(R.id.btn_item_copy);
            btnShare = itemView.findViewById(R.id.btn_item_share);
            btnDelete = itemView.findViewById(R.id.btn_item_delete);
        }
    }
}
"""

with open(f"{package_path}/adapter/FavoritesAdapter.java", "w", encoding="utf-8") as f:
    f.write(adapter_java)

# 2. Refactor MainActivity.java with dynamic Theme UI updating,RenderEffect blur, and high contrast bottom nav
main_activity_java = """package com.yangxinning.praise;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.adapter.FavoritesAdapter;
import com.yangxinning.praise.manager.FavoritesManager;
import com.yangxinning.praise.manager.PraiseManager;
import com.yangxinning.praise.manager.ThemeSettingsManager;
import com.yangxinning.praise.model.PraiseItem;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout rootLayout;
    private ViewFlipper viewFlipper;
    private LinearLayout floatingNavBar;
    private LinearLayout navItemPraise, navItemFavorites, navItemSettings;
    private ImageView navIconPraise, navIconFavorites, navIconSettings;
    private TextView navTextPraise, navTextFavorites, navTextSettings;
    private int currentTabIndex = 0;

    private TextView tvTargetName, tvComplimentContent;
    private CardView cardComplimentWrapper;
    private View btnGenerateCompliment;
    private LinearLayout btnActionFavorite, btnActionCopy, btnActionShare;
    private ImageView ivFavIcon;
    private TextView tvFavLabel;
    private PraiseItem currentPraiseItem;

    private TextView tvFavoritesSubtitle;
    private LinearLayout layoutFavoritesEmpty;
    private RecyclerView rvFavorites;
    private FavoritesAdapter favoritesAdapter;

    private EditText etTargetName;
    private TextView btnSaveName, btnResetName;
    private RadioGroup rgTheme;
    private RadioButton rbThemeLight, rbThemeDark, rbThemeSystem;
    private LinearLayout btnClearFavorites;

    private long lastGenerateClickTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        settingsManager.applyTheme(settingsManager.getThemeMode());

        super.onCreate(savedInstanceState);
        makeEdgeToEdge();
        setContentView(R.layout.activity_main);

        initViews();
        updateThemeUI();
        setupNavigation();
        setupPraiseTab();
        setupFavoritesTab();
        setupSettingsTab();

        generateNewCompliment(false);
    }

    private void makeEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    private void initViews() {
        rootLayout = findViewById(R.id.root_layout);
        viewFlipper = findViewById(R.id.view_flipper);
        floatingNavBar = findViewById(R.id.floating_nav_bar);

        navItemPraise = findViewById(R.id.nav_item_praise);
        navItemFavorites = findViewById(R.id.nav_item_favorites);
        navItemSettings = findViewById(R.id.nav_item_settings);

        navIconPraise = findViewById(R.id.nav_icon_praise);
        navIconFavorites = findViewById(R.id.nav_icon_favorites);
        navIconSettings = findViewById(R.id.nav_icon_settings);

        navTextPraise = findViewById(R.id.nav_text_praise);
        navTextFavorites = findViewById(R.id.nav_text_favorites);
        navTextSettings = findViewById(R.id.nav_text_settings);

        tvTargetName = findViewById(R.id.tv_target_name);
        tvComplimentContent = findViewById(R.id.tv_compliment_content);
        cardComplimentWrapper = findViewById(R.id.card_compliment_wrapper);
        btnGenerateCompliment = findViewById(R.id.btn_generate_compliment);
        btnActionFavorite = findViewById(R.id.btn_action_favorite);
        btnActionCopy = findViewById(R.id.btn_action_copy);
        btnActionShare = findViewById(R.id.btn_action_share);
        ivFavIcon = findViewById(R.id.iv_fav_icon);
        tvFavLabel = findViewById(R.id.tv_fav_label);

        tvFavoritesSubtitle = findViewById(R.id.tv_favorites_subtitle);
        layoutFavoritesEmpty = findViewById(R.id.layout_favorites_empty);
        rvFavorites = findViewById(R.id.rv_favorites);

        etTargetName = findViewById(R.id.et_target_name);
        btnSaveName = findViewById(R.id.btn_save_name);
        btnResetName = findViewById(R.id.btn_reset_name);
        rgTheme = findViewById(R.id.rg_theme);
        rbThemeLight = findViewById(R.id.rb_theme_light);
        rbThemeDark = findViewById(R.id.rb_theme_dark);
        rbThemeSystem = findViewById(R.id.rb_theme_system);
        btnClearFavorites = findViewById(R.id.btn_clear_favorites);
    }

    private void updateThemeUI() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        // Set status bar icons contrast
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decor = getWindow().getDecorView();
            if (isDark) {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            } else {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        // Set dynamic background gradient
        if (rootLayout != null) {
            rootLayout.setBackgroundResource(isDark ? R.drawable.bg_dynamic_gradient_dark : R.drawable.bg_dynamic_gradient_light);
        }

        // Set nav bar background
        if (floatingNavBar != null) {
            floatingNavBar.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_nav_dark : R.drawable.bg_liquid_glass_nav);
        }

        // Set glass card backgrounds
        int cardRes = isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card;
        View cardPraise = findViewById(R.id.card_compliment_inner);
        if (cardPraise != null) cardPraise.setBackgroundResource(cardRes);

        View cardTarget = findViewById(R.id.card_settings_target);
        if (cardTarget != null) cardTarget.setBackgroundResource(cardRes);

        View cardAbout = findViewById(R.id.card_settings_about);
        if (cardAbout != null) cardAbout.setBackgroundResource(cardRes);

        // Apply Android 12+ (API 31+) real dynamic backdrop blur
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                RenderEffect blur = RenderEffect.createBlurEffect(25f, 25f, Shader.TileMode.CLAMP);
                if (floatingNavBar != null) floatingNavBar.setRenderEffect(blur);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        updateNavStyles(currentTabIndex);
    }

    private void setupNavigation() {
        navItemPraise.setOnClickListener(v -> switchTab(0));
        navItemFavorites.setOnClickListener(v -> switchTab(1));
        navItemSettings.setOnClickListener(v -> switchTab(2));
    }

    private void switchTab(int targetIndex) {
        if (currentTabIndex == targetIndex) return;

        viewFlipper.setInAnimation(this, R.anim.fade_in);
        viewFlipper.setOutAnimation(this, R.anim.fade_out);
        viewFlipper.setDisplayedChild(targetIndex);
        currentTabIndex = targetIndex;

        updateNavStyles(targetIndex);

        if (targetIndex == 1) {
            refreshFavoritesData();
        } else if (targetIndex == 2) {
            loadSettingsData();
        }
    }

    private void updateNavStyles(int activeIndex) {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        navItemPraise.setBackground(null);
        navItemFavorites.setBackground(null);
        navItemSettings.setBackground(null);

        int activeColor = Color.parseColor("#FFFFFF");
        int inactiveColor = isDark ? Color.parseColor("#A0A0A0") : Color.parseColor("#616161");

        navIconPraise.setColorFilter(inactiveColor);
        navIconFavorites.setColorFilter(inactiveColor);
        navIconSettings.setColorFilter(inactiveColor);

        navTextPraise.setTextColor(inactiveColor);
        navTextFavorites.setTextColor(inactiveColor);
        navTextSettings.setTextColor(inactiveColor);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.nav_select);
        int selectedPillDrawable = isDark ? R.drawable.bg_nav_item_selected_dark : R.drawable.bg_nav_item_selected;

        if (activeIndex == 0) {
            navItemPraise.setBackgroundResource(selectedPillDrawable);
            navItemPraise.startAnimation(anim);
            navIconPraise.setColorFilter(activeColor);
            navTextPraise.setTextColor(activeColor);
        } else if (activeIndex == 1) {
            navItemFavorites.setBackgroundResource(selectedPillDrawable);
            navItemFavorites.startAnimation(anim);
            navIconFavorites.setColorFilter(activeColor);
            navTextFavorites.setTextColor(activeColor);
        } else if (activeIndex == 2) {
            navItemSettings.setBackgroundResource(selectedPillDrawable);
            navItemSettings.startAnimation(anim);
            navIconSettings.setColorFilter(activeColor);
            navTextSettings.setTextColor(activeColor);
        }
    }

    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return;
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
    }

    private void generateNewCompliment(boolean animate) {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);

        if (animate) {
            cardComplimentWrapper.clearAnimation();
            Animation popAnim = AnimationUtils.loadAnimation(this, R.anim.card_pop);
            cardComplimentWrapper.startAnimation(popAnim);
        }

        tvComplimentContent.setText(currentPraiseItem.getFormattedText());
        updateFavoriteButtonState();
    }

    private void updateFavoriteButtonState() {
        if (currentPraiseItem == null) return;
        boolean isFav = FavoritesManager.getInstance(this).isFavorite(currentPraiseItem.getFormattedText());
        if (isFav) {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_filled);
            tvFavLabel.setText(R.string.btn_favorited);
        } else {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_border);
            tvFavLabel.setText(R.string.btn_favorite);
        }
    }

    private void toggleFavoriteCurrent() {
        if (currentPraiseItem == null) return;
        FavoritesManager favManager = FavoritesManager.getInstance(this);
        boolean isFav = favManager.isFavorite(currentPraiseItem.getFormattedText());

        if (isFav) {
            favManager.removeFavorite(currentPraiseItem.getFormattedText());
            Toast.makeText(this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
        } else {
            favManager.addFavorite(currentPraiseItem);
            Toast.makeText(this, R.string.toast_favorited, Toast.LENGTH_SHORT).show();
        }
        updateFavoriteButtonState();
    }

    private void setupFavoritesTab() {
        rvFavorites.setLayoutManager(new LinearLayoutManager(this));
        favoritesAdapter = new FavoritesAdapter(null, new FavoritesAdapter.OnItemActionListener() {
            @Override
            public void onCopy(PraiseItem item) {
                copyTextToClipboard(item.getFormattedText());
            }

            @Override
            public void onShare(PraiseItem item) {
                shareText(item.getFormattedText());
            }

            @Override
            public void onDelete(PraiseItem item, int position) {
                FavoritesManager.getInstance(MainActivity.this).removeFavorite(item.getId());
                favoritesAdapter.removeItem(position);
                refreshFavoritesHeaderCount();
                updateFavoriteButtonState();
                Toast.makeText(MainActivity.this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
            }
        });
        rvFavorites.setAdapter(favoritesAdapter);
        refreshFavoritesData();
    }

    private void refreshFavoritesData() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        favoritesAdapter.updateData(list);
        refreshFavoritesHeaderCount();
    }

    private void refreshFavoritesHeaderCount() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        int count = list.size();
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvFavoritesSubtitle.setText(String.format("已为 %s 收藏 %d 条专属灵感", targetName, count));

        if (count == 0) {
            layoutFavoritesEmpty.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            layoutFavoritesEmpty.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }
    }

    private void setupSettingsTab() {
        loadSettingsData();

        btnSaveName.setOnClickListener(v -> {
            String newName = etTargetName.getText().toString().trim();
            if (newName.isEmpty()) {
                newName = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager.getInstance(this).setTargetName(newName);
            tvTargetName.setText(newName);
            generateNewCompliment(false);
            Toast.makeText(this, String.format(getString(R.string.toast_name_updated), newName), Toast.LENGTH_SHORT).show();
        });

        btnResetName.setOnClickListener(v -> {
            String defaultName = ThemeSettingsManager.DEFAULT_TARGET;
            etTargetName.setText(defaultName);
            ThemeSettingsManager.getInstance(this).setTargetName(defaultName);
            tvTargetName.setText(defaultName);
            generateNewCompliment(false);
            Toast.makeText(this, String.format(getString(R.string.toast_name_updated), defaultName), Toast.LENGTH_SHORT).show();
        });

        rgTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int mode = ThemeSettingsManager.THEME_SYSTEM;
            if (checkedId == R.id.rb_theme_light) {
                mode = ThemeSettingsManager.THEME_LIGHT;
            } else if (checkedId == R.id.rb_theme_dark) {
                mode = ThemeSettingsManager.THEME_DARK;
            } else if (checkedId == R.id.rb_theme_system) {
                mode = ThemeSettingsManager.THEME_SYSTEM;
            }
            
            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
            if (settingsManager.getThemeMode() != mode) {
                settingsManager.setThemeMode(mode);
                recreate(); // Instantly reload activity to apply real dark/light theme!
            }
        });

        btnClearFavorites.setOnClickListener(v -> showClearFavoritesDialog());
    }

    private void loadSettingsData() {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        etTargetName.setText(settingsManager.getTargetName());

        int mode = settingsManager.getThemeMode();
        if (mode == ThemeSettingsManager.THEME_LIGHT) {
            rbThemeLight.setChecked(true);
        } else if (mode == ThemeSettingsManager.THEME_DARK) {
            rbThemeDark.setChecked(true);
        } else {
            rbThemeSystem.setChecked(true);
        }
    }

    private void showClearFavoritesDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_clear_confirm_title)
                .setMessage(R.string.settings_clear_confirm_msg)
                .setPositiveButton(R.string.settings_clear_confirm_ok, (dialog, which) -> {
                    FavoritesManager.getInstance(MainActivity.this).clearAllFavorites();
                    refreshFavoritesData();
                    updateFavoriteButtonState();
                    Toast.makeText(MainActivity.this, R.string.toast_cleared, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.settings_clear_confirm_cancel, null)
                .show();
    }

    private void copyTextToClipboard(String text) {
        if (text == null || text.isEmpty()) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("YangXinningPraise", text);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void shareText(String text) {
        if (text == null || text.isEmpty()) return;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String shareContent = "【Yang Xinning 专属夸奖】\\n" + text + "\\n\\n—— 来自 夸奖器 App";
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent);
        startActivity(Intent.createChooser(shareIntent, "分享夸奖灵感"));
    }
}
"""

with open(f"{package_path}/MainActivity.java", "w", encoding="utf-8") as f:
    f.write(main_activity_java)

print("Java source code refactored successfully.")
