import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update strings.xml to add author telegram
strings_file = f"{project_dir}/app/src/main/res/values/strings.xml"
with open(strings_file, "r", encoding="utf-8") as f:
    s_code = f.read()

s_code = s_code.replace('</resources>', '    <string name="settings_author_telegram">作者 Telegram：@shuilin791</string>\n</resources>')
with open(strings_file, "w", encoding="utf-8") as f:
    f.write(s_code)

# 2. Update layout_tab_settings.xml: scrollbars="none" + Telegram author row
layout_settings_file = f"{project_dir}/app/src/main/res/layout/layout_tab_settings.xml"
with open(layout_settings_file, "r", encoding="utf-8") as f:
    l_code = f.read()

# Add android:scrollbars="none" to ScrollView
l_code = l_code.replace('<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"', '<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"\n    android:scrollbars="none"')

# Add Telegram row in About section
old_about_card = """            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="12dp"
                android:text="@string/settings_version"
                android:textColor="#007AFF"
                android:textSize="12sp"
                android:textStyle="bold" />"""

new_about_card = """            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="12dp"
                android:text="@string/settings_version"
                android:textColor="#007AFF"
                android:textSize="12sp"
                android:textStyle="bold" />

            <View
                android:layout_width="match_parent"
                android:layout_height="1dp"
                android:layout_marginTop="14dp"
                android:layout_marginBottom="14dp"
                android:background="#20000000" />

            <LinearLayout
                android:id="@+id/btn_author_telegram"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_glass_button_secondary"
                android:clickable="true"
                android:focusable="true"
                android:gravity="center_vertical"
                android:orientation="horizontal"
                android:paddingStart="12dp"
                android:paddingTop="10dp"
                android:paddingEnd="12dp"
                android:paddingBottom="10dp">

                <ImageView
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:contentDescription="Telegram"
                    android:src="@drawable/ic_share"
                    app:tint="#007AFF" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:text="@string/settings_author_telegram"
                    android:textColor="#007AFF"
                    android:textSize="14sp"
                    android:textStyle="bold" />
            </LinearLayout>"""

l_code = l_code.replace(old_about_card, new_about_card)

with open(layout_settings_file, "w", encoding="utf-8") as f:
    f.write(l_code)

# 3. Update layout_tab_praise.xml: scrollbars="none"
layout_praise_file = f"{project_dir}/app/src/main/res/layout/layout_tab_praise.xml"
with open(layout_praise_file, "r", encoding="utf-8") as f:
    p_code = f.read()

p_code = p_code.replace('<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"', '<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"\n    android:scrollbars="none"')
with open(layout_praise_file, "w", encoding="utf-8") as f:
    f.write(p_code)

# 4. Update MainActivity.java: handle btn_author_telegram click (open Telegram link + copy username)
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    m_code = f.read()

old_setup_settings = """        btnClearFavorites.setOnClickListener(v -> showClearFavoritesDialog());
    }"""

new_setup_settings = """        btnClearFavorites.setOnClickListener(v -> showClearFavoritesDialog());

        View btnTelegram = findViewById(R.id.btn_author_telegram);
        if (btnTelegram != null) {
            btnTelegram.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/shuilin791"));
                    startActivity(intent);
                } catch (Exception e) {
                    copyTextToClipboard("@shuilin791");
                    Toast.makeText(MainActivity.this, "已复制作者 Telegram：@shuilin791", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }"""

m_code = m_code.replace(old_setup_settings, new_setup_settings)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(m_code)

print("Scrollbars hidden and Telegram author info added successfully.")
