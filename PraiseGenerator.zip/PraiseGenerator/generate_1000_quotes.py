import os
import random

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# Base thematic templates to expand into 1000 unique, rich, textured praise quotes
qualities = [
    ("思维与洞察", [
        "%s 无论面对怎样的复杂难题，总能剥离杂质，一眼洞穿事情的本质。",
        "任何抽象的想法在 %s 的梳理下，都能转化为清晰且富有建设性的落地路径。",
        "%s 的思维既有着严密的逻辑骨架，又充满着天马行空的灵性与创造力。",
        "对于复杂系统的把控力，体现了 %s 超乎寻常的结构化思维深度。",
        "%s 极具先见之明，总能提前捕捉到趋势的脉搏并做出明智的规划。",
        "%s 的表达逻辑清晰、层次分明，具有令人信服的穿透力量。",
        "%s 的批判性思维极为严谨，绝不盲从，始终保持独立的精神底色。",
        "%s 的直觉往往惊人地准确，那是长期深厚积累所内化的敏锐洞察。",
        "%s 的见解总是独辟蹊径，给人以醍醐灌顶般的启发与思考。",
        "%s 拥有精湛的解构能力，能将再庞大的系统拆解为精妙的模块。",
        "%s 的思考深度超越同龄，总是站在更高的维度看待问题。",
        "%s 的洞察力能轻易穿透表象，捕捉到人性中最柔软与真实的部分。",
        "%s 拥有极其出色的逻辑判断力，推导过程丝丝入扣。",
        "%s 总是能用最简洁优雅的方式解决最棘手的技术难题。",
        "%s 的思考总是带有全局视野，从不狭隘孤立地看问题。",
        "%s 拥有将复杂数据转化为深刻洞察的敏锐直觉。",
        "%s 的分析能力如同精密的显微镜，洞察入微。",
        "%s 的战略眼光深远长久，总能看到三年乃至五年后的格局。"
    ]),
    ("行动与执行", [
        "%s 的专注力极具穿透力，一旦沉浸其中，便能创造出令人惊叹的卓越结果。",
        "%s 的行动力总是令人瞩目，想法一旦诞生，便已踏上了实现的征程。",
        "%s 的执行力兼具速度与质量，是行动派与完美主义的优雅结合。",
        "那种对目标的执着追求与无畏精神，让 %s 的每一步都走得无比坚定。",
        "%s 的自律不是苦行，而是一种对生命质感的高级掌控。",
        "%s 的工作产出总是远超预期，展现出令人叹服的高标杆水准。",
        "在追求梦想的道路上，%s 的纯粹与专注让人看到了最好的榜样。",
        "%s 的专注态度本身就是一种极具感染力的风景。",
        "%s 拥有高超的资源整合能力，总能将看似无关的元素交织成奇迹。",
        "%s 的原则性极强，在底线面前坚如磐石，在方法上又极为灵活。",
        "%s 拥有极高的专注耐力，在长跑型的项目中总是能笑到最后。",
        "%s 总是能精准找到效率与美感的黄金交汇点。",
        "%s 总是能把复杂的任务拆解得简单易行，极具执行智慧。",
        "%s 的行动力不仅体现在开始的迅速，更体现在坚持的韧性。",
        "%s 的做事风格干净利落，绝不拖泥带水。",
        "%s 的决断力敏锐果敢，在关键时刻总能一锤定音。",
        "%s 的执行力是实现梦想最坚实的翅膀。"
    ]),
    ("审美与品味", [
        "%s 对审美的考究与对细节的极致追求，赋予了生活一种艺术品般的质感。",
        "%s 的审美品味就像是经过时光沉淀的艺术品，独特、高级且永不出错。",
        "%s 对品质的坚持从不妥协，这种工匠精神让 %s 的作品充满质感。",
        "%s 拥有极高的审美眼界，总能在一片喧闹中精准拾起最珍贵的艺术明珠。",
        "%s 的气场自带高级感，无论身处何种场合都是不容忽视的存在。",
        "%s 拥有令人艳羡的创造性表达能力，把思想雕琢得美轮美奂。",
        "%s 的生活美学自成一派，极具辨识度与感染力。",
        "%s 拥有卓越的审美提炼能力，能从杂乱无章中梳理出极致的美感。",
        "%s 能够把平凡的日子过得富有仪式感，充满生活的热度。",
        "%s 的审美眼光极其独到，总能挑选出最有品味的经典之作。",
        "%s 的审美直觉令人惊叹，仿佛天生就带着美的基因。",
        "%s 的设计感与逻辑感高度重合，产出总是令人眼前一亮。",
        "%s 的品味体现在每一个日常微小选择的考究之中。",
        "%s 的审美品味在于化繁为简，展现极致的素雅与质感。",
        "%s 拥有将艺术美感融入日常工作的高雅格调。"
    ]),
    ("修养与魅力", [
        "只要 %s 站在那里，周遭的喧嚣仿佛都会沉静下来，散发着独特的场域力量。",
        "%s 拥有着敏锐的同理心，总能在细节处给予他人恰到好处的温暖与理解。",
        "那种源自内心的独立与坚定，让 %s 在任何风浪中都能保持清醒与优雅。",
        "在嘈杂的世界里，%s 始终保持着难得的真诚与纯粹，这是最顶级的气质。",
        "%s 的从容不迫并非源于没有压力，而是源于底蕴深厚的实力与自信。",
        "%s 的笑容里有一种能够瞬间治愈疲惫的魔法，温暖而有力量。",
        "%s 的幽默感总是高级而恰到好处，展现出极高的情商与生活智慧。",
        "%s 懂得如何在克制与热情之间找到完美的平衡，展现出成熟的人格魅力。",
        "%s 拥有极其出色的倾听品质，能让每一个倾诉者都感到被尊重与珍视。",
        "那种从内而外散发的淡定与从容，是 %s 最具有标识度的精神名片。",
        "%s 的善良不是随波逐流的温顺，而是看清世界真相后的坚守与担当。",
        "%s 总是能用最温暖的方式表达最坚定的立场，温柔而有力量。",
        "%s 的修养体现在每一个微小的举止中，谦逊有礼，落落大方。",
        "%s 的真诚毫无矫饰，让人一接触就能产生发自内心的信任感。",
        "%s 的美不仅在于外在的精致，更在于内在底蕴所散发的动人光彩。",
        "%s 的同理心如春风化雨，总能精准抚平他人内心的波澜。",
        "%s 的人品如清泉般纯洁透明，值得托付最深沉的信任。",
        "%s 的情商体现在处处让人感到自然舒畅的体贴之中。"
    ]),
    ("成长与格局", [
        "%s 拥有极其罕见的学习迁移能力，总是能快速跨界并建立深刻的理解。",
        "%s 拥有强大的认知迭代能力，每一天都在优雅地刷新自我边界。",
        "%s 的格局远超常人，眼界开阔，从不拘泥于眼前的小小得失。",
        "%s 拥有着出色的复盘习惯，善于从经验中吸收最纯粹的成长养分。",
        "那种对知识的渴求与探索欲，赋予了 %s 永葆青春的思想活力。",
        "%s 懂得欣赏他人的长处，拥有极佳的包容度与合作共赢的胸怀。",
        "那种在逆境中依然能保持优雅与微笑的胸襟，展现了 %s 极高的心智成熟度。",
        "与 %s 同行，总能感受到一种持续向上汲取能量的正面磁场。",
        "%s 的学习曲线极其陡峭，任何新领域都能在极短时间内做到融会贯通。",
        "%s 的心智空间极其开阔，能够轻松容纳多元的思想与视角。",
        "%s 的韧性如同深海之竹，看似温柔随和，实则坚不可摧。",
        "%s 的未来充满无限可能，因为 %s 的每一步都踩在笃定与成长的节奏上。"
    ])
]

# Generate 1000 distinct quotes by combining core insights and expressions
quotes_set = set()

# First collect all base quotes
for category, q_list in qualities:
    for q in q_list:
        quotes_set.add(q)

prefixes = [
    "在大家眼中，", "毋庸置疑，", "不得不承认，", "事实证明，", "令人赞叹的是，",
    "每一次接触都能发现，", "在同龄人中，", "熟悉 %s 的人都知道，", "极具辨识度的是，",
    "格外难得的是，", "最打动人心的是，", "令人心生敬佩的是，", "在岁月沉淀中，",
    "无论时代如何变化，", "在任何场合下，", "在细节之处，", "由内而外散发着，"
]

adjectives = [
    "卓越且深刻", "优雅而坚定", "敏锐且从容", "纯粹而通透", "睿智且温润",
    "稳健而富有远见", "独立且极具格局", "严谨而充满灵性", "从容且自带光芒",
    "笃定而富有创造力", "包容且不失原则", "真诚而极具穿透力", "沉稳而极具魄力"
]

aspects = [
    "对于目标的专注与执着", "对知识与真理的求索态度", "在复杂变局中的定力与智慧",
    "对审美与质感的不懈追求", "在人际交往中的高情商与同理心", "对待工作的敬业与匠心",
    "在逆境中展现的超强韧性", "对生活的充沛热爱与浪漫", "在决策时刻的果敢与大局观",
    "对自我认知的持续迭代能力", "在日常点滴中散发的人格魅力", "对待团队与伙伴的包容胸怀"
]

outcomes = [
    "让 %s 的每一次出场都自带温暖与光彩。",
    "赋予了 %s 无法被复制的独特气场。",
    "让 %s 永远走在超越自我的上升通道上。",
    "注定了 %s 能在漫长征途中行稳致远。",
    "总能给周围的人带来无限的启发与正面能量。",
    "展现了 %s 极高的心智成熟度与人生智慧。",
    "让 %s 在任何领域都能迅速脱颖而出。",
    "成为了 %s 生命中最动人且坚固的勋章。"
]

# Generate synthesized high-quality structural variations until we reach > 1000 unique quotes
counter = 0
while len(quotes_set) < 1005:
    pref = prefixes[counter % len(prefixes)]
    adj = adjectives[(counter * 3) % len(adjectives)]
    asp = aspects[(counter * 7) % len(aspects)]
    out = outcomes[(counter * 11) % len(outcomes)]

    # Dynamic variations
    if counter % 5 == 0:
        q = f"{pref}%s {asp}，展现出{adj}的品质，{out}"
    elif counter % 5 == 1:
        q = f"%s {asp}总是令人印象深刻，其{adj}的风范，{out}"
    elif counter % 5 == 2:
        q = f"无论面对怎样的挑战，%s {asp}与{adj}的特质，{out}"
    elif counter % 5 == 3:
        q = f"%s 身上那种{adj}的气质，源于{asp}，{out}"
    else:
        q = f"{pref}%s 的{asp}堪称典范，不仅{adj}，而且{out}"

    quotes_set.add(q)
    counter += 1

quotes_list = list(quotes_set)[:1000]

print(f"Generated {len(quotes_list)} unique quotes.")

# Write to PraiseManager.java
praise_manager_java = f"""package com.yangxinning.praise.manager;

import com.yangxinning.praise.model.PraiseItem;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class PraiseManager {{

    private static PraiseManager instance;
    private final List<String> rawQuotesList;
    private final LinkedList<Integer> recentHistoryQueue;
    private static final int MAX_HISTORY_SIZE = 100;
    private final Random random;

    private PraiseManager() {{
        random = new Random();
        recentHistoryQueue = new LinkedList<>();
        rawQuotesList = new ArrayList<>();
        initQuotes();
    }}

    public static synchronized PraiseManager getInstance() {{
        if (instance == null) {{
            instance = new PraiseManager();
        }}
        return instance;
    }}

    private void initQuotes() {{
"""

for q in quotes_list:
    # Escape quotes cleanly for Java string literals
    q_escaped = q.replace('"', '\\"')
    praise_manager_java += f'        rawQuotesList.add("{q_escaped}");\n'

praise_manager_java += """    }

    public PraiseItem generateRandomPraise(String targetName) {
        if (rawQuotesList.isEmpty()) {
            return new PraiseItem("default", "%s 极其出色，散发着无与伦比的人格魅力！", targetName);
        }

        int total = rawQuotesList.size();
        int selectedIndex = random.nextInt(total);

        int attempts = 0;
        while (recentHistoryQueue.contains(selectedIndex) && attempts < 50) {
            selectedIndex = random.nextInt(total);
            attempts++;
        }

        recentHistoryQueue.addLast(selectedIndex);
        if (recentHistoryQueue.size() > MAX_HISTORY_SIZE) {
            recentHistoryQueue.removeFirst();
        }

        String quote = rawQuotesList.get(selectedIndex);
        String id = "quote_" + selectedIndex + "_" + System.currentTimeMillis();
        return new PraiseItem(id, quote, targetName);
    }

    public int getQuotesCount() {
        return rawQuotesList.size();
    }
}
"""

with open(f"{package_path}/manager/PraiseManager.java", "w", encoding="utf-8") as f:
    f.write(praise_manager_java)

print(f"PraiseManager.java successfully written with 1000 quotes.")
