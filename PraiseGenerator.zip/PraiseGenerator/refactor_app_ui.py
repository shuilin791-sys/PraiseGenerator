import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update strings.xml (App name -> 夸奖器, clean subtitle)
strings_xml = """<resources>
    <string name="app_name">夸奖器</string>
    <string name="default_target_name">Yang Xinning</string>
    <string name="subtitle_main">专属灵感与夸奖</string>
    <string name="tab_praise">夸夸</string>
    <string name="tab_favorites">收藏</string>
    <string name="tab_settings">设置</string>
    
    <string name="btn_generate">生成专属夸奖</string>
    <string name="btn_favorite">收藏</string>
    <string name="btn_favorited">已收藏</string>
    <string name="btn_copy">复制夸奖</string>
    <string name="btn_share">分享灵感</string>
    
    <string name="favorites_title">精选夸奖收藏箱</string>
    <string name="favorites_subtitle">记录属于 %1$s 的每一个闪光时刻</string>
    <string name="favorites_empty_title">暂无收藏的夸奖</string>
    <string name="favorites_empty_desc">点击主页夸奖卡片下方的“收藏”按钮，将精彩语录保存在这里吧！</string>
    
    <string name="settings_title">系统偏好设置</string>
    <string name="settings_target_section">夸奖对象自定义</string>
    <string name="settings_target_hint">请输入要夸奖的对象姓名</string>
    <string name="settings_target_save">保存姓名</string>
    <string name="settings_target_reset">重置为 Yang Xinning</string>
    
    <string name="settings_theme_section">外观与主题风格</string>
    <string name="settings_theme_light">浅色模式 (Light Mode)</string>
    <string name="settings_theme_dark">深色模式 (Dark Liquid)</string>
    <string name="settings_theme_system">跟随系统 (Auto Adapt)</string>
    
    <string name="settings_data_section">数据与隐私管理</string>
    <string name="settings_clear_favorites">清空所有收藏</string>
    <string name="settings_clear_confirm_title">确认清空？</string>
    <string name="settings_clear_confirm_msg">此操作将彻底删除所有已保存的夸奖语录，无法恢复。</string>
    <string name="settings_clear_confirm_ok">确认清空</string>
    <string name="settings_clear_confirm_cancel">取消</string>
    
    <string name="settings_about_section">关于应用</string>
    <string name="settings_about_app_desc">夸奖器 是一款精美优雅的高质感原生 Android 夸奖生成工具。内置 100+ 条精心撰写的专属夸奖语录，带来流畅顺滑的交互体验。</string>
    <string name="settings_version">版本 v1.0.0 (Build 2026.11)</string>
    
    <string name="toast_copied">夸奖语录已复制到剪贴板！</string>
    <string name="toast_favorited">已成功加入收藏！</string>
    <string name="toast_unfavorited">已取消收藏</string>
    <string name="toast_cleared">所有收藏已成功清空</string>
    <string name="toast_name_updated">夸奖对象已更新为：%1$s</string>
</resources>
"""

with open(f"{project_dir}/app/src/main/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(strings_xml)

# 2. Colors.xml
colors_xml = """<resources>
    <color name="ios_blue">#007AFF</color>
    <color name="ios_blue_dark">#0A84FF</color>

    <color name="text_primary_light">#1D1D1F</color>
    <color name="text_secondary_light">#6E6E73</color>
    
    <color name="text_primary_dark">#F5F5F7</color>
    <color name="text_secondary_dark">#A1A1A6</color>

    <color name="transparent">#00000000</color>
</resources>
"""

with open(f"{project_dir}/app/src/main/res/values/colors.xml", "w", encoding="utf-8") as f:
    f.write(colors_xml)

# 3. Drawables overhaul for unified Liquid Glass
# Background Light: Clean, soft iOS mesh
bg_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#F1F5F9"
        android:centerColor="#E2E8F0"
        android:endColor="#F8FAFC"
        android:type="linear" />
</shape>
"""

# Background Dark: Deep Midnight Obsidian
bg_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#090D16"
        android:centerColor="#111827"
        android:endColor="#1E293B"
        android:type="linear" />
</shape>
"""

# Liquid Glass Card - Light Mode (Frosted Glass with 1.5dp specular border, NO inner white box!)
bg_glass_card_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <gradient
        android:angle="135"
        android:startColor="#CCFFFFFF"
        android:endColor="#99FFFFFF"
        android:type="linear" />
    <stroke
        android:width="1.5dp"
        android:color="#E2E8F0" />
</shape>
"""

# Liquid Glass Card - Dark Mode (Obsidian Frosted Glass with Specular Glow)
bg_glass_card_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <gradient
        android:angle="135"
        android:startColor="#30FFFFFF"
        android:endColor="#15FFFFFF"
        android:type="linear" />
    <stroke
        android:width="1.5dp"
        android:color="#40FFFFFF" />
</shape>
"""

# Liquid Glass Floating Capsule Nav - Light Mode
bg_nav_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <gradient
        android:angle="90"
        android:startColor="#F0FFFFFF"
        android:endColor="#D5FFFFFF"
        android:type="linear" />
    <stroke
        android:width="1.5dp"
        android:color="#CBD5E1" />
</shape>
"""

# Liquid Glass Floating Capsule Nav - Dark Mode
bg_nav_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <gradient
        android:angle="90"
        android:startColor="#401E293B"
        android:endColor="#300F172A"
        android:type="linear" />
    <stroke
        android:width="1.5dp"
        android:color="#50FFFFFF" />
</shape>
"""

# Nav Selected Pill - Light Mode
bg_nav_selected_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#007AFF" />
</shape>
"""

# Nav Selected Pill - Dark Mode
bg_nav_selected_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#0A84FF" />
</shape>
"""

# Primary Glass Action Button
bg_glass_button = """<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#30FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="24dp" />
            <gradient
                android:angle="135"
                android:startColor="#007AFF"
                android:endColor="#3B82F6"
                android:type="linear" />
        </shape>
    </item>
</ripple>
"""

# Secondary Glass Button
bg_glass_button_secondary = """<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20000000">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <solid android:color="#15007AFF" />
            <stroke
                android:width="1dp"
                android:color="#30007AFF" />
        </shape>
    </item>
</ripple>
"""

# Input Box
bg_glass_input = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#10000000" />
    <stroke
        android:width="1dp"
        android:color="#30000000" />
</shape>
"""

drawables = {
    "bg_dynamic_gradient_light.xml": bg_light,
    "bg_dynamic_gradient_dark.xml": bg_dark,
    "bg_liquid_glass_card.xml": bg_glass_card_light,
    "bg_liquid_glass_card_dark.xml": bg_glass_card_dark,
    "bg_liquid_glass_nav.xml": bg_nav_light,
    "bg_liquid_glass_nav_dark.xml": bg_nav_dark,
    "bg_nav_item_selected.xml": bg_nav_selected_light,
    "bg_nav_item_selected_dark.xml": bg_nav_selected_dark,
    "bg_glass_button.xml": bg_glass_button,
    "bg_glass_button_secondary.xml": bg_glass_button_secondary,
    "bg_glass_input.xml": bg_glass_input
}

for filename, content in drawables.items():
    with open(f"{project_dir}/app/src/main/res/drawable/{filename}", "w", encoding="utf-8") as f:
        f.write(content)

print("Redesigned drawables successfully.")
