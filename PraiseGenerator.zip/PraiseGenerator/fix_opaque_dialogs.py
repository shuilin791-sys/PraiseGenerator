import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Create dedicated solid opaque backgrounds for dialogs to prevent ANY background text bleed-through!

bg_dialog_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="28dp" />
    <solid android:color="#FFFFFFFF" />
    <stroke
        android:width="1.5dp"
        android:color="#CBD5E1" />
</shape>
"""

bg_dialog_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="28dp" />
    <solid android:color="#1E293B" />
    <stroke
        android:width="1.5dp"
        android:color="#475569" />
</shape>
"""

bg_dialog_input_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#F1F5F9" />
    <stroke
        android:width="1dp"
        android:color="#CBD5E1" />
</shape>
"""

bg_dialog_input_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#0F172A" />
    <stroke
        android:width="1dp"
        android:color="#334155" />
</shape>
"""

bg_dialog_item_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#F1F5F9" />
    <stroke
        android:width="1dp"
        android:color="#E2E8F0" />
</shape>
"""

bg_dialog_item_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#0F172A" />
    <stroke
        android:width="1dp"
        android:color="#334155" />
</shape>
"""

drawables = {
    "bg_dialog_card_light.xml": bg_dialog_light,
    "bg_dialog_card_dark.xml": bg_dialog_dark,
    "bg_dialog_input_light.xml": bg_dialog_input_light,
    "bg_dialog_input_dark.xml": bg_dialog_input_dark,
    "bg_dialog_item_light.xml": bg_dialog_item_light,
    "bg_dialog_item_dark.xml": bg_dialog_item_dark
}

for filename, content in drawables.items():
    with open(f"{project_dir}/app/src/main/res/drawable/{filename}", "w", encoding="utf-8") as f:
        f.write(content)

print("Solid dialog drawables created.")
