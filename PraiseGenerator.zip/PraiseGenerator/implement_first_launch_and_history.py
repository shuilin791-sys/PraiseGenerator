import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update strings.xml
strings_xml = """<resources>
    <string name="app_name">夸奖器</string>
    <string name="default_target_name">Alex</string>
    <string name="subtitle_main">专属灵感与夸奖</string>
    <string name="tab_praise">夸夸</string>
    <string name="tab_favorites">收藏</string>
    <string name="tab_settings">设置</string>
    
    <string name="btn_generate">生成专属夸奖</string>
    <string name="btn_favorite">收藏</string>
    <string name="btn_favorited">已收藏</string>
    <string name="btn_copy">复制夸奖</string>
    <string name="btn_share">分享灵感</string>
    
    <string name="favorites_title">精选夸奖收藏箱</string>
    <string name="favorites_subtitle">记录属于 %1$s 的每一个闪光时刻</string>
    <string name="favorites_empty_title">暂无收藏的夸奖</string>
    <string name="favorites_empty_desc">点击主页夸奖卡片下方的“收藏”按钮，将精彩语录保存在这里吧！</string>
    
    <string name="settings_title">系统偏好设置</string>
    <string name="settings_target_section">夸奖对象自定义</string>
    <string name="settings_target_hint">请输入要夸奖的对象姓名</string>
    <string name="settings_target_save">保存姓名</string>
    <string name="settings_target_history">名称历史记录</string>
    
    <string name="settings_theme_section">外观与主题风格</string>
    <string name="settings_theme_light">浅色模式 (Light Mode)</string>
    <string name="settings_theme_dark">深色模式 (Dark Liquid)</string>
    <string name="settings_theme_system">跟随系统 (Auto Adapt)</string>
    
    <string name="settings_data_section">数据与隐私管理</string>
    <string name="settings_clear_favorites">清空所有收藏</string>
    <string name="settings_clear_confirm_title">确认清空？</string>
    <string name="settings_clear_confirm_msg">此操作将彻底删除所有已保存的夸奖语录，无法恢复。</string>
    <string name="settings_clear_confirm_ok">确认清空</string>
    <string name="settings_clear_confirm_cancel">取消</string>
    
    <string name="settings_about_section">关于应用</string>
    <string name="settings_about_app_desc">夸奖器 是一款精美优雅的高质感原生 Android 夸奖生成工具。内置 200+ 条精心撰写的专属夸奖语录，带来流畅顺滑的交互体验。</string>
    <string name="settings_version">版本 v1.0.0 (Build 2026.11)</string>
    
    <string name="toast_copied">夸奖语录已复制到剪贴板！</string>
    <string name="toast_favorited">已成功加入收藏！</string>
    <string name="toast_unfavorited">已取消收藏</string>
    <string name="toast_cleared">所有收藏已成功清空</string>
    <string name="toast_name_updated">夸奖对象已更新为：%1$s</string>

    <string name="first_launch_title">欢迎使用夸奖器 ✨</string>
    <string name="first_launch_desc">请输入你想要专门夸奖的对象姓名（例如：Alex、小灵感）：</string>
    <string name="first_launch_btn">开启专属夸奖</string>
</resources>
"""

with open(f"{project_dir}/app/src/main/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(strings_xml)

# 2. Update layout_tab_settings.xml (Replace Reset to Alex with 名称历史记录)
settings_xml_file = f"{project_dir}/app/src/main/res/layout/layout_tab_settings.xml"
with open(settings_xml_file, "r", encoding="utf-8") as f:
    s_content = f.read()

s_content = s_content.replace('@string/settings_target_reset', '@string/settings_target_history')
with open(settings_xml_file, "w", encoding="utf-8") as f:
    f.write(s_content)

# 3. Update ThemeSettingsManager.java with first-launch state and name history management
theme_settings_java = """package com.yangxinning.praise.manager;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class ThemeSettingsManager {

    private static final String PREF_NAME = "yang_xinning_praise_settings";
    private static final String KEY_TARGET_NAME = "key_target_name";
    private static final String KEY_THEME_MODE = "key_theme_mode";
    private static final String KEY_FIRST_LAUNCH = "key_first_launch";
    private static final String KEY_NAME_HISTORY = "key_name_history_json";

    public static final String DEFAULT_TARGET = "Alex";

    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;
    public static final int THEME_SYSTEM = 2;

    private static ThemeSettingsManager instance;
    private final SharedPreferences prefs;

    private ThemeSettingsManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized ThemeSettingsManager getInstance(Context context) {
        if (instance == null) {
            instance = new ThemeSettingsManager(context);
        }
        return instance;
    }

    public boolean isFirstLaunch() {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true);
    }

    public void setFirstLaunchCompleted() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply();
    }

    public String getTargetName() {
        return prefs.getString(KEY_TARGET_NAME, DEFAULT_TARGET);
    }

    public void setTargetName(String name) {
        if (name == null || name.trim().isEmpty()) {
            name = DEFAULT_TARGET;
        }
        String cleanName = name.trim();
        prefs.edit().putString(KEY_TARGET_NAME, cleanName).apply();
        addNameHistory(cleanName);
    }

    public List<String> getNameHistory() {
        List<String> list = new ArrayList<>();
        String jsonStr = prefs.getString(KEY_NAME_HISTORY, "[]");
        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                String val = array.optString(i);
                if (val != null && !val.trim().isEmpty() && !list.contains(val.trim())) {
                    list.add(val.trim());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (list.isEmpty()) {
            list.add(DEFAULT_TARGET);
        }
        return list;
    }

    public void addNameHistory(String name) {
        if (name == null || name.trim().isEmpty()) return;
        String cleanName = name.trim();
        List<String> history = getNameHistory();
        history.remove(cleanName);
        history.add(0, cleanName); // recent first

        if (history.size() > 10) {
            history = history.subList(0, 10);
        }

        try {
            JSONArray array = new JSONArray();
            for (String item : history) {
                array.put(item);
            }
            prefs.edit().putString(KEY_NAME_HISTORY, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getThemeMode() {
        return prefs.getInt(KEY_THEME_MODE, THEME_SYSTEM);
    }

    public void setThemeMode(int mode) {
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply();
        applyTheme(mode);
    }

    public void applyTheme(int mode) {
        switch (mode) {
            case THEME_LIGHT:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case THEME_DARK:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case THEME_SYSTEM:
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }
    }
}
"""

with open(f"{package_path}/manager/ThemeSettingsManager.java", "w", encoding="utf-8") as f:
    f.write(theme_settings_java)

# 4. Update MainActivity.java to add First Launch Input Dialog (supporting Light & Dark Mode) and Name History Dialog
main_activity_java = """package com.yangxinning.praise;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.adapter.FavoritesAdapter;
import com.yangxinning.praise.manager.FavoritesManager;
import com.yangxinning.praise.manager.PraiseManager;
import com.yangxinning.praise.manager.ThemeSettingsManager;
import com.yangxinning.praise.model.PraiseItem;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout rootLayout;
    private ViewFlipper viewFlipper;
    private LinearLayout floatingNavBar;
    private LinearLayout navItemPraise, navItemFavorites, navItemSettings;
    private ImageView navIconPraise, navIconFavorites, navIconSettings;
    private TextView navTextPraise, navTextFavorites, navTextSettings;
    private int currentTabIndex = 0;

    private TextView tvTargetName, tvComplimentContent;
    private View cardComplimentWrapper;
    private View btnGenerateCompliment;
    private LinearLayout btnActionFavorite, btnActionCopy, btnActionShare;
    private ImageView ivFavIcon;
    private TextView tvFavLabel;
    private PraiseItem currentPraiseItem;

    private TextView tvFavoritesSubtitle;
    private LinearLayout layoutFavoritesEmpty;
    private RecyclerView rvFavorites;
    private FavoritesAdapter favoritesAdapter;

    private EditText etTargetName;
    private TextView btnSaveName, btnResetName;
    private RadioGroup rgTheme;
    private RadioButton rbThemeLight, rbThemeDark, rbThemeSystem;
    private LinearLayout btnClearFavorites;

    private long lastGenerateClickTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        settingsManager.applyTheme(settingsManager.getThemeMode());

        super.onCreate(savedInstanceState);
        makeEdgeToEdge();
        setContentView(R.layout.activity_main);

        initViews();
        updateThemeUI();
        setupNavigation();
        setupPraiseTab();
        setupFavoritesTab();
        setupSettingsTab();

        generateNewCompliment(false);

        // Check if first launch, show first launch input dialog
        if (settingsManager.isFirstLaunch()) {
            showFirstLaunchDialog();
        }
    }

    private void makeEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    private void initViews() {
        rootLayout = findViewById(R.id.root_layout);
        viewFlipper = findViewById(R.id.view_flipper);
        floatingNavBar = findViewById(R.id.floating_nav_bar);

        navItemPraise = findViewById(R.id.nav_item_praise);
        navItemFavorites = findViewById(R.id.nav_item_favorites);
        navItemSettings = findViewById(R.id.nav_item_settings);

        navIconPraise = findViewById(R.id.nav_icon_praise);
        navIconFavorites = findViewById(R.id.nav_icon_favorites);
        navIconSettings = findViewById(R.id.nav_icon_settings);

        navTextPraise = findViewById(R.id.nav_text_praise);
        navTextFavorites = findViewById(R.id.nav_text_favorites);
        navTextSettings = findViewById(R.id.nav_text_settings);

        tvTargetName = findViewById(R.id.tv_target_name);
        tvComplimentContent = findViewById(R.id.tv_compliment_content);
        cardComplimentWrapper = findViewById(R.id.card_compliment_wrapper);
        btnGenerateCompliment = findViewById(R.id.btn_generate_compliment);
        btnActionFavorite = findViewById(R.id.btn_action_favorite);
        btnActionCopy = findViewById(R.id.btn_action_copy);
        btnActionShare = findViewById(R.id.btn_action_share);
        ivFavIcon = findViewById(R.id.iv_fav_icon);
        tvFavLabel = findViewById(R.id.tv_fav_label);

        tvFavoritesSubtitle = findViewById(R.id.tv_favorites_subtitle);
        layoutFavoritesEmpty = findViewById(R.id.layout_favorites_empty);
        rvFavorites = findViewById(R.id.rv_favorites);

        etTargetName = findViewById(R.id.et_target_name);
        btnSaveName = findViewById(R.id.btn_save_name);
        btnResetName = findViewById(R.id.btn_reset_name); // Reused for Name History
        rgTheme = findViewById(R.id.rg_theme);
        rbThemeLight = findViewById(R.id.rb_theme_light);
        rbThemeDark = findViewById(R.id.rb_theme_dark);
        rbThemeSystem = findViewById(R.id.rb_theme_system);
        btnClearFavorites = findViewById(R.id.btn_clear_favorites);
    }

    private void updateThemeUI() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decor = getWindow().getDecorView();
            if (isDark) {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            } else {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        if (rootLayout != null) {
            rootLayout.setBackgroundResource(isDark ? R.drawable.bg_dynamic_gradient_dark : R.drawable.bg_dynamic_gradient_light);
        }

        if (floatingNavBar != null) {
            floatingNavBar.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_nav_dark : R.drawable.bg_liquid_glass_nav);
        }

        int cardRes = isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card;

        if (cardComplimentWrapper != null) cardComplimentWrapper.setBackgroundResource(cardRes);

        View cardTarget = findViewById(R.id.card_settings_target);
        if (cardTarget != null) cardTarget.setBackgroundResource(cardRes);

        View cardTheme = findViewById(R.id.card_settings_theme);
        if (cardTheme != null) cardTheme.setBackgroundResource(cardRes);

        View cardClear = findViewById(R.id.btn_clear_favorites);
        if (cardClear != null) cardClear.setBackgroundResource(cardRes);

        View cardAbout = findViewById(R.id.card_settings_about);
        if (cardAbout != null) cardAbout.setBackgroundResource(cardRes);

        int textColor = isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F");
        if (rbThemeLight != null) rbThemeLight.setTextColor(textColor);
        if (rbThemeDark != null) rbThemeDark.setTextColor(textColor);
        if (rbThemeSystem != null) rbThemeSystem.setTextColor(textColor);

        updateNavStyles(currentTabIndex);
    }

    private void showFirstLaunchDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 50, 60, 50);
        layout.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(R.string.first_launch_title);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(R.string.first_launch_desc);
        tvDesc.setTextSize(14);
        tvDesc.setTextColor(isDark ? Color.parseColor("#A1A1A6") : Color.parseColor("#6E6E73"));
        tvDesc.setPadding(0, 16, 0, 24);
        layout.addView(tvDesc);

        final EditText input = new EditText(this);
        input.setHint("如：Alex、小灵感");
        input.setHintTextColor(isDark ? Color.parseColor("#6E6E73") : Color.parseColor("#A1A1A6"));
        input.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        input.setBackgroundResource(R.drawable.bg_glass_input);
        input.setPadding(30, 24, 30, 24);
        layout.addView(input);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(layout)
                .setCancelable(false)
                .setPositiveButton(R.string.first_launch_btn, (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        name = ThemeSettingsManager.DEFAULT_TARGET;
                    }
                    ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(MainActivity.this);
                    settingsManager.setTargetName(name);
                    settingsManager.setFirstLaunchCompleted();
                    tvTargetName.setText(name);
                    generateNewCompliment(false);
                    Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), name), Toast.LENGTH_SHORT).show();
                })
                .create();

        dialog.show();
    }

    private void setupNavigation() {
        navItemPraise.setOnClickListener(v -> switchTab(0));
        navItemFavorites.setOnClickListener(v -> switchTab(1));
        navItemSettings.setOnClickListener(v -> switchTab(2));
    }

    private void switchTab(int targetIndex) {
        if (currentTabIndex == targetIndex) return;

        viewFlipper.setInAnimation(this, R.anim.fade_in);
        viewFlipper.setOutAnimation(this, R.anim.fade_out);
        viewFlipper.setDisplayedChild(targetIndex);
        currentTabIndex = targetIndex;

        updateNavStyles(targetIndex);

        if (targetIndex == 1) {
            refreshFavoritesData();
        } else if (targetIndex == 2) {
            loadSettingsData();
        }
    }

    private void updateNavStyles(int activeIndex) {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        navItemPraise.setBackground(null);
        navItemFavorites.setBackground(null);
        navItemSettings.setBackground(null);

        int activeColor = Color.parseColor("#FFFFFF");
        int inactiveColor = isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#475569");

        navIconPraise.setColorFilter(inactiveColor);
        navIconFavorites.setColorFilter(inactiveColor);
        navIconSettings.setColorFilter(inactiveColor);

        navTextPraise.setTextColor(inactiveColor);
        navTextFavorites.setTextColor(inactiveColor);
        navTextSettings.setTextColor(inactiveColor);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.nav_select);
        int selectedPillDrawable = isDark ? R.drawable.bg_nav_item_selected_dark : R.drawable.bg_nav_item_selected;

        if (activeIndex == 0) {
            navItemPraise.setBackgroundResource(selectedPillDrawable);
            navItemPraise.startAnimation(anim);
            navIconPraise.setColorFilter(activeColor);
            navTextPraise.setTextColor(activeColor);
        } else if (activeIndex == 1) {
            navItemFavorites.setBackgroundResource(selectedPillDrawable);
            navItemFavorites.startAnimation(anim);
            navIconFavorites.setColorFilter(activeColor);
            navTextFavorites.setTextColor(activeColor);
        } else if (activeIndex == 2) {
            navItemSettings.setBackgroundResource(selectedPillDrawable);
            navItemSettings.startAnimation(anim);
            navIconSettings.setColorFilter(activeColor);
            navTextSettings.setTextColor(activeColor);
        }
    }

    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return;
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
    }

    private void generateNewCompliment(boolean animate) {
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            if (tvTargetName != null) {
                tvTargetName.setText(targetName);
            }

            currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);
            if (currentPraiseItem == null) return;

            if (tvComplimentContent != null) {
                tvComplimentContent.setText(currentPraiseItem.getFormattedText());
                if (animate) {
                    tvComplimentContent.setAlpha(0.3f);
                    tvComplimentContent.animate()
                            .alpha(1.0f)
                            .setDuration(200)
                            .start();
                }
            }

            updateFavoriteButtonState();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateFavoriteButtonState() {
        if (currentPraiseItem == null) return;
        boolean isFav = FavoritesManager.getInstance(this).isFavorite(currentPraiseItem.getFormattedText());
        if (isFav) {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_filled);
            tvFavLabel.setText(R.string.btn_favorited);
        } else {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_border);
            tvFavLabel.setText(R.string.btn_favorite);
        }
    }

    private void toggleFavoriteCurrent() {
        if (currentPraiseItem == null) return;
        FavoritesManager favManager = FavoritesManager.getInstance(this);
        boolean isFav = favManager.isFavorite(currentPraiseItem.getFormattedText());

        if (isFav) {
            favManager.removeFavorite(currentPraiseItem.getFormattedText());
            Toast.makeText(this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
        } else {
            favManager.addFavorite(currentPraiseItem);
            Toast.makeText(this, R.string.toast_favorited, Toast.LENGTH_SHORT).show();
        }
        updateFavoriteButtonState();
    }

    private void setupFavoritesTab() {
        rvFavorites.setLayoutManager(new LinearLayoutManager(this));
        favoritesAdapter = new FavoritesAdapter(null, new FavoritesAdapter.OnItemActionListener() {
            @Override
            public void onCopy(PraiseItem item) {
                copyTextToClipboard(item.getFormattedText());
            }

            @Override
            public void onShare(PraiseItem item) {
                shareText(item.getFormattedText());
            }

            @Override
            public void onDelete(PraiseItem item, int position) {
                FavoritesManager.getInstance(MainActivity.this).removeFavorite(item.getId());
                favoritesAdapter.removeItem(position);
                refreshFavoritesHeaderCount();
                updateFavoriteButtonState();
                Toast.makeText(MainActivity.this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
            }
        });
        rvFavorites.setAdapter(favoritesAdapter);
        refreshFavoritesData();
    }

    private void refreshFavoritesData() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        favoritesAdapter.updateData(list);
        refreshFavoritesHeaderCount();
    }

    private void refreshFavoritesHeaderCount() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        int count = list.size();
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvFavoritesSubtitle.setText(String.format("已为 %s 收藏 %d 条专属灵感", targetName, count));

        if (count == 0) {
            layoutFavoritesEmpty.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            layoutFavoritesEmpty.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }
    }

    private void setupSettingsTab() {
        loadSettingsData();

        btnSaveName.setOnClickListener(v -> {
            String newName = etTargetName.getText().toString().trim();
            if (newName.isEmpty()) {
                newName = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager.getInstance(this).setTargetName(newName);
            tvTargetName.setText(newName);
            generateNewCompliment(false);
            Toast.makeText(this, String.format(getString(R.string.toast_name_updated), newName), Toast.LENGTH_SHORT).show();
        });

        // Name History Button
        btnResetName.setOnClickListener(v -> showNameHistoryDialog());

        rgTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int mode = ThemeSettingsManager.THEME_SYSTEM;
            if (checkedId == R.id.rb_theme_light) {
                mode = ThemeSettingsManager.THEME_LIGHT;
            } else if (checkedId == R.id.rb_theme_dark) {
                mode = ThemeSettingsManager.THEME_DARK;
            } else if (checkedId == R.id.rb_theme_system) {
                mode = ThemeSettingsManager.THEME_SYSTEM;
            }

            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
            if (settingsManager.getThemeMode() != mode) {
                settingsManager.setThemeMode(mode);
                recreate();
            }
        });

        btnClearFavorites.setOnClickListener(v -> showClearFavoritesDialog());
    }

    private void showNameHistoryDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        List<String> historyList = settingsManager.getNameHistory();

        if (historyList.isEmpty()) {
            Toast.makeText(this, "暂无历史记录", Toast.LENGTH_SHORT).show();
            return;
        }

        final String[] items = historyList.toArray(new String[0]);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("选择历史名称")
                .setItems(items, (d, which) -> {
                    String selectedName = items[which];
                    etTargetName.setText(selectedName);
                    settingsManager.setTargetName(selectedName);
                    tvTargetName.setText(selectedName);
                    generateNewCompliment(false);
                    Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), selectedName), Toast.LENGTH_SHORT).show();
                })
                .create();

        dialog.show();
    }

    private void loadSettingsData() {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        etTargetName.setText(settingsManager.getTargetName());

        int mode = settingsManager.getThemeMode();
        if (mode == ThemeSettingsManager.THEME_LIGHT) {
            rbThemeLight.setChecked(true);
        } else if (mode == ThemeSettingsManager.THEME_DARK) {
            rbThemeDark.setChecked(true);
        } else {
            rbThemeSystem.setChecked(true);
        }
    }

    private void showClearFavoritesDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_clear_confirm_title)
                .setMessage(R.string.settings_clear_confirm_msg)
                .setPositiveButton(R.string.settings_clear_confirm_ok, (dialog, which) -> {
                    FavoritesManager.getInstance(MainActivity.this).clearAllFavorites();
                    refreshFavoritesData();
                    updateFavoriteButtonState();
                    Toast.makeText(MainActivity.this, R.string.toast_cleared, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.settings_clear_confirm_cancel, null)
                .show();
    }

    private void copyTextToClipboard(String text) {
        if (text == null || text.isEmpty()) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("PraiseText", text);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void shareText(String text) {
        if (text == null || text.isEmpty()) return;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String shareContent = "【专属夸奖灵感】\\n" + text + "\\n\\n—— 来自 夸奖器 App";
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent);
        startActivity(Intent.createChooser(shareIntent, "分享夸奖灵感"));
    }
}
"""

with open(f"{package_path}/MainActivity.java", "w", encoding="utf-8") as f:
    f.write(main_activity_java)

print("First launch dialog, Name history, and 200+ quotes implemented successfully.")
