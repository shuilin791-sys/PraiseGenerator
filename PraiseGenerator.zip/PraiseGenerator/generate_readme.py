import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"

readme_content = """# 夸奖器 (Praise Generator for Android)

一款专为 **Yang Xinning** 打造的高质感原生 Android 夸奖语录生成应用。基于 Apple iOS Liquid Glass（液态玻璃）设计语言，采用纯 Java + XML 原生架构开发。

![Android](https://img.shields.io/badge/Platform-Android-green.svg)
![Language](https://img.shields.io/badge/Language-Java-orange.svg)
![UI Design](https://img.shields.io/badge/Design-Liquid%20Glass-blue.svg)
![License](https://img.shields.io/badge/License-MIT-brightgreen.svg)

---

## ✨ 核心功能亮点

- **105+ 原创高质感语录**：涵盖智慧洞察、逻辑思维、审美品味、行动力与人格魅力。
- **智能防重复队列**：内置内存历史记录算法，确保高频点击生成不重样。
- **一键互动体验**：支持夸奖语录的秒级收藏、一键复制到剪贴板与唤起系统原生分享。
- **本地持久化收藏箱**：收藏语录永久保存在本地存储中，随时查阅与管理。
- **自定义夸奖对象与主题**：支持自定义夸奖姓名，内置浅色模式 (Light Mode) 与深色模式 (Dark Liquid) 实时切换。
- **零闪退与高频点击优化**：采用 `ViewPropertyAnimator` 渐变动画与内存一级缓存，性能极致稳定。

---

## 🎨 视觉与设计特色

- **标志性悬浮胶囊导航栏**：悬浮于屏幕底部的半透明液态玻璃胶囊 Navigation Bar，高对比度清晰图标与流体高光。
- **单层微光玻璃卡片**：去除沉闷黑影，结合高透玻璃材质与自然渐变背景。
- **真实深浅色双模式**：
  - **浅色模式**：清透高雅的 iOS 极简白蓝渐变。
  - **深色模式**：深邃高级的夜蓝黑耀玻璃与亮白字体对比。

---

## 🛠 技术栈与架构

- **开发语言**：Java (JDK 8 / 11)
- **UI 布局**：Android Native XML Layouts + Vector Drawables
- **兼容性**：完全兼容 Android Studio & 手机端 **CodeAssist** IDE
- **最小 SDK 支持**：API 24 (Android 7.0+)
- **目标 SDK**：API 34 (Android 14)

---

## 🚀 编译与运行说明

### 在 Android Studio 中编译：
1. 克隆本项目：
   ```bash
   git clone https://github.com/YOUR_USERNAME/PraiseGenerator.git
   ```
2. 打开 Android Studio，点击 `File -> Open` 选择项目根目录。
3. 等待 Gradle 同步完成后，点击右上角的 **Run 'app'** (▶) 即可编译并安装。

### 在手机端 CodeAssist 中编译：
1. 下载解压 zip 文件或使用 Git 导入 CodeAssist。
2. 打开项目选择 **兼容模式**。
3. 点击右上角 **`▶` ➔ `Run Debug · app`** 即可在手机上直接构建 APK！

---

## 📄 开源许可证

本项目基于 [MIT License](LICENSE) 开源。
"""

with open(f"{project_dir}/README.md", "w", encoding="utf-8") as f:
    f.write(readme_content)

print("README.md generated successfully.")
