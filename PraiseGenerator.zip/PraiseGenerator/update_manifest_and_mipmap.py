import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"

# Create mipmap directory
mipmap_dir = f"{project_dir}/app/src/main/res/mipmap"
os.makedirs(mipmap_dir, exist_ok=True)

# 1. Launcher icon XML
ic_launcher_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#007AFF"
        android:pathData="M0,0h108v108h-108z"/>
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M54,24L64,44L84,47L69,61L73,81L54,71L35,81L39,61L24,47L44,44Z"/>
</vector>
"""

with open(f"{mipmap_dir}/ic_launcher.xml", "w") as f:
    f.write(ic_launcher_xml)

with open(f"{mipmap_dir}/ic_launcher_round.xml", "w") as f:
    f.write(ic_launcher_xml)

# 2. Update AndroidManifest.xml to use @drawable/ic_tab_praise or @mipmap/ic_launcher safely
manifest_xml = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.yangxinning.praise">

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_tab_praise"
        android:label="@string/app_name"
        android:roundIcon="@drawable/ic_tab_praise"
        android:supportsRtl="true"
        android:theme="@style/Theme.YangXinningPraise">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:windowSoftInputMode="adjustPan">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
"""

with open(f"{project_dir}/app/src/main/AndroidManifest.xml", "w") as f:
    f.write(manifest_xml)

print("AndroidManifest and mipmap updated.")
