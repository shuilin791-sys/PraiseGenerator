import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update strings.xml (add card export strings)
strings_file = f"{project_dir}/app/src/main/res/values/strings.xml"
with open(strings_file, "r", encoding="utf-8") as f:
    s_code = f.read()

s_code = s_code.replace('</resources>', '    <string name="btn_export_card">生成美图</string>\n    <string name="toast_card_saved">美图卡片已成功保存至相册！</string>\n</resources>')
with open(strings_file, "w", encoding="utf-8") as f:
    f.write(s_code)

# 2. Update layout_tab_praise.xml: add "生成美图" button in action bar
layout_praise_file = f"{project_dir}/app/src/main/res/layout/layout_tab_praise.xml"
with open(layout_praise_file, "r", encoding="utf-8") as f:
    l_code = f.read()

old_action_bar = """                <!-- Action Bar (Favorite, Copy, Share) -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:gravity="center_vertical"
                    android:orientation="horizontal">

                    <!-- Favorite Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_favorite"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginEnd="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:id="@+id/iv_fav_icon"
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_favorite"
                            android:src="@drawable/ic_favorite_border"
                            app:tint="#FF2D55" />

                        <TextView
                            android:id="@+id/tv_fav_label"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="@string/btn_favorite"
                            android:textColor="#FF2D55"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Copy Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_copy"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="4dp"
                        android:layout_marginEnd="4dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_copy"
                            android:src="@drawable/ic_copy"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="复制"
                            android:textColor="#007AFF"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Share Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_share"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_share"
                            android:src="@drawable/ic_share"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="分享"
                            android:textColor="#007AFF"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                </LinearLayout>"""

new_action_bar = """                <!-- Action Bar (Favorite, Export Card, Copy, Share) -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:gravity="center_vertical"
                    android:orientation="horizontal">

                    <!-- Favorite Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_favorite"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginEnd="4dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="4dp"
                        android:paddingEnd="4dp">

                        <ImageView
                            android:id="@+id/iv_fav_icon"
                            android:layout_width="16dp"
                            android:layout_height="16dp"
                            android:contentDescription="@string/btn_favorite"
                            android:src="@drawable/ic_favorite_border"
                            app:tint="#FF2D55" />

                        <TextView
                            android:id="@+id/tv_fav_label"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="3dp"
                            android:text="@string/btn_favorite"
                            android:textColor="#FF2D55"
                            android:textSize="11sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Export Card Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_export_card"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="2dp"
                        android:layout_marginEnd="2dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="4dp"
                        android:paddingEnd="4dp">

                        <ImageView
                            android:layout_width="16dp"
                            android:layout_height="16dp"
                            android:contentDescription="@string/btn_export_card"
                            android:src="@drawable/ic_sparkle"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="3dp"
                            android:text="@string/btn_export_card"
                            android:textColor="#007AFF"
                            android:textSize="11sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Copy Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_copy"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="2dp"
                        android:layout_marginEnd="2dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="4dp"
                        android:paddingEnd="4dp">

                        <ImageView
                            android:layout_width="16dp"
                            android:layout_height="16dp"
                            android:contentDescription="@string/btn_copy"
                            android:src="@drawable/ic_copy"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="3dp"
                            android:text="复制"
                            android:textColor="#007AFF"
                            android:textSize="11sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Share Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_share"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="4dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="4dp"
                        android:paddingEnd="4dp">

                        <ImageView
                            android:layout_width="16dp"
                            android:layout_height="16dp"
                            android:contentDescription="@string/btn_share"
                            android:src="@drawable/ic_share"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="3dp"
                            android:text="分享"
                            android:textColor="#007AFF"
                            android:textSize="11sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                </LinearLayout>"""

l_code = l_code.replace(old_action_bar, new_action_bar)

with open(layout_praise_file, "w", encoding="utf-8") as f:
    f.write(l_code)

# 3. Update MainActivity.java: Typewriter text animation & Card Image Bitmap Exporting
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    m_code = f.read()

# Add imports for Bitmap, Canvas, MediaStore, Handler
imports_to_add = """import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;"""

m_code = m_code.replace("import android.graphics.Color;", "import android.graphics.Color;\n" + imports_to_add)

# Add member variables for Typewriter Handler
members_to_add = """    private LinearLayout btnActionExportCard;
    private Handler typewriterHandler = new Handler(Looper.getMainLooper());
    private Runnable typewriterRunnable;"""

m_code = m_code.replace("private PraiseItem currentPraiseItem;", "private PraiseItem currentPraiseItem;\n" + members_to_add)

# Add binding in initViews
m_code = m_code.replace("btnActionShare = findViewById(R.id.btn_action_share);", "btnActionShare = findViewById(R.id.btn_action_share);\n        btnActionExportCard = findViewById(R.id.btn_action_export_card);")

# Add click listener in setupPraiseTab
old_praise_listeners = """        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));"""

new_praise_listeners = """        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        if (btnActionExportCard != null) {
            btnActionExportCard.setOnClickListener(v -> exportCardAsImage());
        }"""

m_code = m_code.replace(old_praise_listeners, new_praise_listeners)

# Update generateNewCompliment with Typewriter animation
old_gen_method = """    private void generateNewCompliment(boolean animate) {
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            if (tvTargetName != null) {
                tvTargetName.setText(targetName);
            }

            currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);
            if (currentPraiseItem == null) return;

            if (tvComplimentContent != null) {
                tvComplimentContent.setText(currentPraiseItem.getFormattedText());
                if (animate) {
                    tvComplimentContent.setAlpha(0.3f);
                    tvComplimentContent.animate()
                            .alpha(1.0f)
                            .setDuration(200)
                            .start();
                }
            }

            updateFavoriteButtonState();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }"""

new_gen_method = """    private void generateNewCompliment(boolean animate) {
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            if (tvTargetName != null) {
                tvTargetName.setText(targetName);
            }

            currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);
            if (currentPraiseItem == null) return;

            final String fullText = currentPraiseItem.getFormattedText();

            if (tvComplimentContent != null) {
                if (animate) {
                    // Typewriter Effect
                    if (typewriterRunnable != null) {
                        typewriterHandler.removeCallbacks(typewriterRunnable);
                    }
                    tvComplimentContent.setText("");
                    final int[] index = {0};
                    typewriterRunnable = new Runnable() {
                        @Override
                        public void run() {
                            if (index[0] <= fullText.length()) {
                                tvComplimentContent.setText(fullText.substring(0, index[0]));
                                index[0]++;
                                typewriterHandler.postDelayed(this, 18); // 18ms per character
                            }
                        }
                    };
                    typewriterHandler.post(typewriterRunnable);
                } else {
                    tvComplimentContent.setText(fullText);
                }
            }

            updateFavoriteButtonState();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportCardAsImage() {
        if (cardComplimentWrapper == null) return;
        try {
            Bitmap bitmap = Bitmap.createBitmap(cardComplimentWrapper.getWidth(), cardComplimentWrapper.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            cardComplimentWrapper.draw(canvas);

            String title = "PraiseCard_" + System.currentTimeMillis();
            String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, title, "来自夸奖器App的精美卡片");

            if (savedPath != null) {
                Toast.makeText(this, R.string.toast_card_saved, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "美图卡片生成成功！", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace Spanish;
            Toast.makeText(this, "卡片导出失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }"""

# Fix syntax if any
new_gen_method = new_gen_method.replace("e.printStackTrace Spanish;", "e.printStackTrace();")
m_code = m_code.replace(old_gen_method, new_gen_method)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(m_code)

print("Typewriter animation and Card Image Export added successfully.")
