import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

main_activity_file = f"{package_path}/MainActivity.java"

with open(main_activity_file, "r", encoding="utf-8") as f:
    code = f.read()

# Replace showCustomFirstLaunchDialog and showCustomNameHistoryDialog with 100% opaque, ultra-clear dialogs
old_first_dialog = """    private void showCustomFirstLaunchDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 50, 60, 50);
        layout.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(R.string.first_launch_title);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(R.string.first_launch_desc);
        tvDesc.setTextSize(14);
        tvDesc.setTextColor(isDark ? Color.parseColor("#A1A1A6") : Color.parseColor("#6E6E73"));
        tvDesc.setPadding(0, 16, 0, 24);
        layout.addView(tvDesc);

        final EditText input = new EditText(this);
        input.setHint("如：Alex、小灵感");
        input.setHintTextColor(isDark ? Color.parseColor("#6E6E73") : Color.parseColor("#A1A1A6"));
        input.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        input.setBackgroundResource(R.drawable.bg_glass_input);
        input.setPadding(30, 24, 30, 24);
        layout.addView(input);

        TextView btnConfirm = new TextView(this);
        btnConfirm.setText(R.string.first_launch_btn);
        btnConfirm.setTextColor(Color.WHITE);
        btnConfirm.setTextSize(15);
        btnConfirm.setTypeface(null, android.graphics.Typeface.BOLD);
        btnConfirm.setGravity(Gravity.CENTER);
        btnConfirm.setBackgroundResource(R.drawable.bg_glass_button);

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 120);
        btnParams.topMargin = 32;
        btnConfirm.setLayoutParams(btnParams);
        layout.addView(btnConfirm);

        dialog.setContentView(layout);
        dialog.setCancelable(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86);
            dialog.getWindow().setAttributes(lp);
        }

        btnConfirm.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                name = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(MainActivity.this);
            settingsManager.setTargetName(name);
            settingsManager.setFirstLaunchCompleted();
            tvTargetName.setText(name);
            generateNewCompliment(false);
            Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), name), Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }"""

new_first_dialog = """    private void showCustomFirstLaunchDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(64, 56, 64, 56);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(R.string.first_launch_title);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(R.string.first_launch_desc);
        tvDesc.setTextSize(14);
        tvDesc.setTextColor(isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#64748B"));
        tvDesc.setPadding(0, 16, 0, 24);
        layout.addView(tvDesc);

        final EditText input = new EditText(this);
        input.setHint("如：Alex、小灵感");
        input.setHintTextColor(isDark ? Color.parseColor("#64748B") : Color.parseColor("#94A3B8"));
        input.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        input.setBackgroundResource(isDark ? R.drawable.bg_dialog_input_dark : R.drawable.bg_dialog_input_light);
        input.setPadding(32, 28, 32, 28);
        layout.addView(input);

        TextView btnConfirm = new TextView(this);
        btnConfirm.setText(R.string.first_launch_btn);
        btnConfirm.setTextColor(Color.WHITE);
        btnConfirm.setTextSize(15);
        btnConfirm.setTypeface(null, android.graphics.Typeface.BOLD);
        btnConfirm.setGravity(Gravity.CENTER);
        btnConfirm.setBackgroundResource(R.drawable.bg_glass_button);

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 124);
        btnParams.topMargin = 36;
        btnConfirm.setLayoutParams(btnParams);
        layout.addView(btnConfirm);

        dialog.setContentView(layout);
        dialog.setCancelable(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.65f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        btnConfirm.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                name = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(MainActivity.this);
            settingsManager.setTargetName(name);
            settingsManager.setFirstLaunchCompleted();
            tvTargetName.setText(name);
            generateNewCompliment(false);
            Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), name), Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }"""

old_history_dialog = """    private void showCustomNameHistoryDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        List<String> historyList = settingsManager.getNameHistory();

        if (historyList.isEmpty()) {
            Toast.makeText(this, "暂无历史名称记录", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 44, 50, 44);
        layout.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("名称历史记录");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scrollParams.topMargin = 20;
        scrollView.setLayoutParams(scrollParams);

        LinearLayout historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(LinearLayout.VERTICAL);

        for (String nameItem : historyList) {
            TextView tvItem = new TextView(this);
            tvItem.setText(nameItem);
            tvItem.setTextSize(15);
            tvItem.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#007AFF"));
            tvItem.setBackgroundResource(R.drawable.bg_glass_button_secondary);
            tvItem.setPadding(30, 24, 30, 24);

            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            itemParams.bottomMargin = 14;
            tvItem.setLayoutParams(itemParams);

            tvItem.setOnClickListener(v -> {
                etTargetName.setText(nameItem);
                settingsManager.setTargetName(nameItem);
                tvTargetName.setText(nameItem);
                generateNewCompliment(false);
                Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), nameItem), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            historyContainer.addView(tvItem);
        }

        scrollView.addView(historyContainer);
        layout.addView(scrollView);

        dialog.setContentView(layout);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86);
            dialog.getWindow().setAttributes(lp);
        }

        dialog.show();
    }"""

new_history_dialog = """    private void showCustomNameHistoryDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        List<String> historyList = settingsManager.getNameHistory();

        if (historyList.isEmpty()) {
            Toast.makeText(this, "暂无历史名称记录", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(64, 56, 64, 56);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("名称历史记录");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scrollParams.topMargin = 24;
        scrollView.setLayoutParams(scrollParams);

        LinearLayout historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(LinearLayout.VERTICAL);

        for (String nameItem : historyList) {
            TextView tvItem = new TextView(this);
            tvItem.setText(nameItem);
            tvItem.setTextSize(15);
            tvItem.setTypeface(null, android.graphics.Typeface.BOLD);
            tvItem.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#007AFF"));
            tvItem.setBackgroundResource(isDark ? R.drawable.bg_dialog_item_dark : R.drawable.bg_dialog_item_light);
            tvItem.setPadding(32, 26, 32, 26);

            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            itemParams.bottomMargin = 14;
            tvItem.setLayoutParams(itemParams);

            tvItem.setOnClickListener(v -> {
                etTargetName.setText(nameItem);
                settingsManager.setTargetName(nameItem);
                tvTargetName.setText(nameItem);
                generateNewCompliment(false);
                Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), nameItem), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            historyContainer.addView(tvItem);
        }

        scrollView.addView(historyContainer);
        layout.addView(scrollView);

        dialog.setContentView(layout);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.65f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        dialog.show();
    }"""

code = code.replace(old_first_dialog, new_first_dialog)
code = code.replace(old_history_dialog, new_history_dialog)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(code)

print("MainActivity.java dialogs updated with 100% solid, non-bleeding backgrounds.")
