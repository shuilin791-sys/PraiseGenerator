package com.yangxinning.praise.adapter;

import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.R;
import com.yangxinning.praise.model.PraiseItem;

import java.util.ArrayList;
import java.util.List;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder> {

    public interface OnItemActionListener {
        void onCopy(PraiseItem item);
        void onShare(PraiseItem item);
        void onDelete(PraiseItem item, int position);
        void onExportCard(PraiseItem item);
    }

    private final List<PraiseItem> itemList;
    private final OnItemActionListener listener;

    public FavoritesAdapter(List<PraiseItem> list, OnItemActionListener listener) {
        this.itemList = (list != null) ? list : new ArrayList<>();
        this.listener = listener;
    }

    public void updateData(List<PraiseItem> newList) {
        this.itemList.clear();
        if (newList != null) {
            this.itemList.addAll(newList);
        }
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (position >= 0 && position < itemList.size()) {
            itemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, itemList.size() - position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_favorite_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PraiseItem item = itemList.get(position);
        holder.tvText.setText(item.getFormattedText());
        holder.tvDate.setText(item.getFormattedDate());

        boolean isDark = (holder.itemView.getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (holder.cardInner != null) {
            holder.cardInner.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);
        }

        if (holder.btnExportCard != null) {
            holder.btnExportCard.setOnClickListener(v -> {
                if (listener != null) listener.onExportCard(item);
            });
        }

        holder.btnCopy.setOnClickListener(v -> {
            if (listener != null) listener.onCopy(item);
        });

        holder.btnShare.setOnClickListener(v -> {
            if (listener != null) listener.onShare(item);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(item, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View cardInner;
        TextView tvText;
        TextView tvDate;
        ImageView btnExportCard;
        ImageView btnCopy;
        ImageView btnShare;
        ImageView btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardInner = itemView.findViewById(R.id.card_item_inner);
            tvText = itemView.findViewById(R.id.tv_item_text);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            btnExportCard = itemView.findViewById(R.id.btn_item_export_card);
            btnCopy = itemView.findViewById(R.id.btn_item_copy);
            btnShare = itemView.findViewById(R.id.btn_item_share);
            btnDelete = itemView.findViewById(R.id.btn_item_delete);
        }
    }
}
