package com.yangxinning.praise.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PraiseItem implements Serializable {
    private String id;
    private String rawQuote;
    private String formattedText;
    private long timestamp;
    private String targetName;
    private String category;

    public PraiseItem() {
    }

    public PraiseItem(String id, String rawQuote, String targetName, String category) {
        this.id = id;
        this.rawQuote = rawQuote;
        this.targetName = (targetName != null && !targetName.trim().isEmpty()) ? targetName.trim() : "Alex";
        this.category = (category != null) ? category : "全部";
        this.timestamp = System.currentTimeMillis();
        this.formattedText = safeFormat(rawQuote, this.targetName);
    }

    private String safeFormat(String quote, String name) {
        if (quote == null) return "";
        try {
            if (quote.contains("%s")) {
                return String.format(quote, name);
            } else {
                return quote;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return quote.replace("%s", name);
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRawQuote() {
        return rawQuote;
    }

    public void setRawQuote(String rawQuote) {
        this.rawQuote = rawQuote;
    }

    public String getFormattedText() {
        if (formattedText == null || formattedText.isEmpty()) {
            return safeFormat(rawQuote, targetName != null ? targetName : "Alex");
        }
        return formattedText;
    }

    public void setFormattedText(String formattedText) {
        this.formattedText = formattedText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
        this.formattedText = safeFormat(rawQuote, targetName);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getFormattedDate() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        } catch (Exception e) {
            return "";
        }
    }
}
