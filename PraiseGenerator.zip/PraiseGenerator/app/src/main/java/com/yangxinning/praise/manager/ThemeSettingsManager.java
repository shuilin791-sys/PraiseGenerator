package com.yangxinning.praise.manager;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class ThemeSettingsManager {

    private static final String PREF_NAME = "yang_xinning_praise_settings";
    private static final String KEY_TARGET_NAME = "key_target_name";
    private static final String KEY_THEME_MODE = "key_theme_mode";
    private static final String KEY_FIRST_LAUNCH = "key_first_launch";
    private static final String KEY_NAME_HISTORY = "key_name_history_json";

    public static final String DEFAULT_TARGET = "Alex";

    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;
    public static final int THEME_SYSTEM = 2;

    private static ThemeSettingsManager instance;
    private final SharedPreferences prefs;

    private ThemeSettingsManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized ThemeSettingsManager getInstance(Context context) {
        if (instance == null) {
            instance = new ThemeSettingsManager(context);
        }
        return instance;
    }

    public boolean isFirstLaunch() {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true);
    }

    public void setFirstLaunchCompleted() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply();
    }

    public String getTargetName() {
        return prefs.getString(KEY_TARGET_NAME, DEFAULT_TARGET);
    }

    public void setTargetName(String name) {
        if (name == null || name.trim().isEmpty()) {
            name = DEFAULT_TARGET;
        }
        String cleanName = name.trim();
        prefs.edit().putString(KEY_TARGET_NAME, cleanName).apply();
        addNameHistory(cleanName);
    }

    public List<String> getNameHistory() {
        List<String> list = new ArrayList<>();
        String jsonStr = prefs.getString(KEY_NAME_HISTORY, "[]");
        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                String val = array.optString(i);
                if (val != null && !val.trim().isEmpty() && !list.contains(val.trim())) {
                    list.add(val.trim());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list; // Pure history without auto-seeding Alex!
    }

    public void addNameHistory(String name) {
        if (name == null || name.trim().isEmpty()) return;
        String cleanName = name.trim();
        List<String> history = getNameHistory();
        history.remove(cleanName);
        history.add(0, cleanName); // recent first

        if (history.size() > 10) {
            history = history.subList(0, 10);
        }

        try {
            JSONArray array = new JSONArray();
            for (String item : history) {
                array.put(item);
            }
            prefs.edit().putString(KEY_NAME_HISTORY, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getThemeMode() {
        return prefs.getInt(KEY_THEME_MODE, THEME_SYSTEM);
    }

    public void setThemeMode(int mode) {
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply();
        applyTheme(mode);
    }

    public void applyTheme(int mode) {
        switch (mode) {
            case THEME_LIGHT:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case THEME_DARK:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case THEME_SYSTEM:
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }
    }
}
