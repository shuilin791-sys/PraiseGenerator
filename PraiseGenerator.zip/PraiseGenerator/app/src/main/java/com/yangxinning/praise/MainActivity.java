package com.yangxinning.praise;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Shader;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.adapter.FavoritesAdapter;
import com.yangxinning.praise.manager.FavoritesManager;
import com.yangxinning.praise.manager.PraiseManager;
import com.yangxinning.praise.manager.ThemeSettingsManager;
import com.yangxinning.praise.model.PraiseItem;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout rootLayout;
    private ViewFlipper viewFlipper;
    private LinearLayout floatingNavBar;
    private LinearLayout navItemPraise, navItemFavorites, navItemSettings;
    private ImageView navIconPraise, navIconFavorites, navIconSettings;
    private TextView navTextPraise, navTextFavorites, navTextSettings;
    private int currentTabIndex = 0;

    private TextView tvTargetName, tvComplimentContent;
    private View cardComplimentWrapper;
    private View btnGenerateCompliment;
    private LinearLayout btnActionFavorite, btnActionCopy, btnActionShare;
    private ImageView ivFavIcon;
    private TextView tvFavLabel;
    private PraiseItem currentPraiseItem;
    private LinearLayout btnActionExportCard;
    private Handler typewriterHandler = new Handler(Looper.getMainLooper());
    private Runnable typewriterRunnable;

    private TextView tvFavoritesSubtitle;
    private LinearLayout layoutFavoritesEmpty;
    private RecyclerView rvFavorites;
    private FavoritesAdapter favoritesAdapter;

    private EditText etTargetName;
    private TextView btnSaveName, btnResetName;
    private RadioGroup rgTheme;
    private RadioButton rbThemeLight, rbThemeDark, rbThemeSystem;
    private LinearLayout btnClearFavorites;

    private long lastGenerateClickTime = 0;
    private String activeCategory = "全部";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        settingsManager.applyTheme(settingsManager.getThemeMode());

        super.onCreate(savedInstanceState);
        makeEdgeToEdge();
        setContentView(R.layout.activity_main);

        initViews();
        updateThemeUI();
        setupNavigation();
        setupPraiseTab();
        setupFavoritesTab();
        setupSettingsTab();

        generateNewCompliment(false);

        // Check first launch
        if (settingsManager.isFirstLaunch()) {
            showCustomFirstLaunchDialog();
        }
    }

    private void makeEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    private void initViews() {
        rootLayout = findViewById(R.id.root_layout);
        viewFlipper = findViewById(R.id.view_flipper);
        floatingNavBar = findViewById(R.id.floating_nav_bar);

        navItemPraise = findViewById(R.id.nav_item_praise);
        navItemFavorites = findViewById(R.id.nav_item_favorites);
        navItemSettings = findViewById(R.id.nav_item_settings);

        navIconPraise = findViewById(R.id.nav_icon_praise);
        navIconFavorites = findViewById(R.id.nav_icon_favorites);
        navIconSettings = findViewById(R.id.nav_icon_settings);

        navTextPraise = findViewById(R.id.nav_text_praise);
        navTextFavorites = findViewById(R.id.nav_text_favorites);
        navTextSettings = findViewById(R.id.nav_text_settings);

        tvTargetName = findViewById(R.id.tv_target_name);
        tvComplimentContent = findViewById(R.id.tv_compliment_content);
        cardComplimentWrapper = findViewById(R.id.card_compliment_wrapper);
        btnGenerateCompliment = findViewById(R.id.btn_generate_compliment);
        btnActionFavorite = findViewById(R.id.btn_action_favorite);
        btnActionCopy = findViewById(R.id.btn_action_copy);
        btnActionShare = findViewById(R.id.btn_action_share);
        btnActionExportCard = findViewById(R.id.btn_action_export_card);
        ivFavIcon = findViewById(R.id.iv_fav_icon);
        tvFavLabel = findViewById(R.id.tv_fav_label);

        tvFavoritesSubtitle = findViewById(R.id.tv_favorites_subtitle);
        layoutFavoritesEmpty = findViewById(R.id.layout_favorites_empty);
        rvFavorites = findViewById(R.id.rv_favorites);

        etTargetName = findViewById(R.id.et_target_name);
        btnSaveName = findViewById(R.id.btn_save_name);
        btnResetName = findViewById(R.id.btn_reset_name);
        rgTheme = findViewById(R.id.rg_theme);
        rbThemeLight = findViewById(R.id.rb_theme_light);
        rbThemeDark = findViewById(R.id.rb_theme_dark);
        rbThemeSystem = findViewById(R.id.rb_theme_system);
        btnClearFavorites = findViewById(R.id.btn_clear_favorites);
    }

    private void updateThemeUI() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decor = getWindow().getDecorView();
            if (isDark) {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            } else {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        if (rootLayout != null) {
            rootLayout.setBackgroundResource(isDark ? R.drawable.bg_dynamic_gradient_dark : R.drawable.bg_dynamic_gradient_light);
        }

        if (floatingNavBar != null) {
            floatingNavBar.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_nav_dark : R.drawable.bg_liquid_glass_nav);
        }

        int cardRes = isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card;

        if (cardComplimentWrapper != null) cardComplimentWrapper.setBackgroundResource(cardRes);

        View cardTarget = findViewById(R.id.card_settings_target);
        if (cardTarget != null) cardTarget.setBackgroundResource(cardRes);

        View cardTheme = findViewById(R.id.card_settings_theme);
        if (cardTheme != null) cardTheme.setBackgroundResource(cardRes);

        View cardClear = findViewById(R.id.btn_clear_favorites);
        if (cardClear != null) cardClear.setBackgroundResource(cardRes);

        View cardAbout = findViewById(R.id.card_settings_about);
        if (cardAbout != null) cardAbout.setBackgroundResource(cardRes);

        int textColor = isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F");
        if (rbThemeLight != null) rbThemeLight.setTextColor(textColor);
        if (rbThemeDark != null) rbThemeDark.setTextColor(textColor);
        if (rbThemeSystem != null) rbThemeSystem.setTextColor(textColor);

        updateNavStyles(currentTabIndex);
    }

    // Seamless 100% Custom Liquid Glass First Launch Dialog (Zero System Window Box!)
    private void showCustomFirstLaunchDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(64, 56, 64, 56);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(R.string.first_launch_title);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(R.string.first_launch_desc);
        tvDesc.setTextSize(14);
        tvDesc.setTextColor(isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#64748B"));
        tvDesc.setPadding(0, 16, 0, 24);
        layout.addView(tvDesc);

        final EditText input = new EditText(this);
        input.setHint("如：Alex、小灵感");
        input.setHintTextColor(isDark ? Color.parseColor("#64748B") : Color.parseColor("#94A3B8"));
        input.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        input.setBackgroundResource(isDark ? R.drawable.bg_dialog_input_dark : R.drawable.bg_dialog_input_light);
        input.setPadding(32, 28, 32, 28);
        layout.addView(input);

        TextView btnConfirm = new TextView(this);
        btnConfirm.setText(R.string.first_launch_btn);
        btnConfirm.setTextColor(Color.WHITE);
        btnConfirm.setTextSize(15);
        btnConfirm.setTypeface(null, android.graphics.Typeface.BOLD);
        btnConfirm.setGravity(Gravity.CENTER);
        btnConfirm.setBackgroundResource(R.drawable.bg_glass_button);

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 124);
        btnParams.topMargin = 36;
        btnConfirm.setLayoutParams(btnParams);
        layout.addView(btnConfirm);

        dialog.setContentView(layout);
        dialog.setCancelable(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.65f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        btnConfirm.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                name = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(MainActivity.this);
            settingsManager.setTargetName(name);
            settingsManager.setFirstLaunchCompleted();
            tvTargetName.setText(name);
            generateNewCompliment(false);
            Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), name), Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void setupNavigation() {
        navItemPraise.setOnClickListener(v -> switchTab(0));
        navItemFavorites.setOnClickListener(v -> switchTab(1));
        navItemSettings.setOnClickListener(v -> switchTab(2));
    }

    private void switchTab(int targetIndex) {
        if (currentTabIndex == targetIndex) return;

        viewFlipper.setInAnimation(this, R.anim.fade_in);
        viewFlipper.setOutAnimation(this, R.anim.fade_out);
        viewFlipper.setDisplayedChild(targetIndex);
        currentTabIndex = targetIndex;

        updateNavStyles(targetIndex);

        if (targetIndex == 1) {
            refreshFavoritesData();
        } else if (targetIndex == 2) {
            loadSettingsData();
        }
    }

    private void updateNavStyles(int activeIndex) {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        navItemPraise.setBackground(null);
        navItemFavorites.setBackground(null);
        navItemSettings.setBackground(null);

        int activeColor = Color.parseColor("#FFFFFF");
        int inactiveColor = isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#475569");

        navIconPraise.setColorFilter(inactiveColor);
        navIconFavorites.setColorFilter(inactiveColor);
        navIconSettings.setColorFilter(inactiveColor);

        navTextPraise.setTextColor(inactiveColor);
        navTextFavorites.setTextColor(inactiveColor);
        navTextSettings.setTextColor(inactiveColor);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.nav_select);
        int selectedPillDrawable = isDark ? R.drawable.bg_nav_item_selected_dark : R.drawable.bg_nav_item_selected;

        if (activeIndex == 0) {
            navItemPraise.setBackgroundResource(selectedPillDrawable);
            navItemPraise.startAnimation(anim);
            navIconPraise.setColorFilter(activeColor);
            navTextPraise.setTextColor(activeColor);
        } else if (activeIndex == 1) {
            navItemFavorites.setBackgroundResource(selectedPillDrawable);
            navItemFavorites.startAnimation(anim);
            navIconFavorites.setColorFilter(activeColor);
            navTextFavorites.setTextColor(activeColor);
        } else if (activeIndex == 2) {
            navItemSettings.setBackgroundResource(selectedPillDrawable);
            navItemSettings.startAnimation(anim);
            navIconSettings.setColorFilter(activeColor);
            navTextSettings.setTextColor(activeColor);
        }
    }

    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        setupCategoryChips();

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return;
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        if (btnActionExportCard != null) {
            btnActionExportCard.setOnClickListener(v -> exportCardAsImage());
        }
    }

    private void setupCategoryChips() {
        TextView chipAll = findViewById(R.id.chip_cat_all);
        TextView chipWork = findViewById(R.id.chip_cat_workplace);
        TextView chipDaily = findViewById(R.id.chip_cat_daily);
        TextView chipAcademic = findViewById(R.id.chip_cat_academic);
        TextView chipHumor = findViewById(R.id.chip_cat_humor);

        View.OnClickListener chipListener = v -> {
            boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            int selDrawable = isDark ? R.drawable.bg_nav_item_selected_dark : R.drawable.bg_nav_item_selected;

            if (chipAll != null) { chipAll.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipAll.setTextColor(Color.parseColor("#007AFF")); }
            if (chipWork != null) { chipWork.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipWork.setTextColor(Color.parseColor("#007AFF")); }
            if (chipDaily != null) { chipDaily.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipDaily.setTextColor(Color.parseColor("#007AFF")); }
            if (chipAcademic != null) { chipAcademic.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipAcademic.setTextColor(Color.parseColor("#007AFF")); }
            if (chipHumor != null) { chipHumor.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipHumor.setTextColor(Color.parseColor("#007AFF")); }

            TextView selChip = (TextView) v;
            selChip.setBackgroundResource(selDrawable);
            selChip.setTextColor(Color.WHITE);

            int id = v.getId();
            if (id == R.id.chip_cat_workplace) activeCategory = "职场";
            else if (id == R.id.chip_cat_daily) activeCategory = "日常";
            else if (id == R.id.chip_cat_academic) activeCategory = "学术";
            else if (id == R.id.chip_cat_humor) activeCategory = "幽默";
            else activeCategory = "全部";

            generateNewCompliment(true);
        };

        if (chipAll != null) chipAll.setOnClickListener(chipListener);
        if (chipWork != null) chipWork.setOnClickListener(chipListener);
        if (chipDaily != null) chipDaily.setOnClickListener(chipListener);
        if (chipAcademic != null) chipAcademic.setOnClickListener(chipListener);
        if (chipHumor != null) chipHumor.setOnClickListener(chipListener);
    }

    private void generateNewCompliment(boolean animate) {
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            if (tvTargetName != null) {
                tvTargetName.setText(targetName);
            }

            currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);
            if (currentPraiseItem == null) return;

            final String fullText = currentPraiseItem.getFormattedText();

            if (tvComplimentContent != null) {
                if (animate) {
                    // Typewriter Effect
                    if (typewriterRunnable != null) {
                        typewriterHandler.removeCallbacks(typewriterRunnable);
                    }
                    tvComplimentContent.setText("");
                    final int[] index = {0};
                    typewriterRunnable = new Runnable() {
                        @Override
                        public void run() {
                            if (index[0] <= fullText.length()) {
                                tvComplimentContent.setText(fullText.substring(0, index[0]));
                                index[0]++;
                                typewriterHandler.postDelayed(this, 18); // 18ms per character
                            }
                        }
                    };
                    typewriterHandler.post(typewriterRunnable);
                } else {
                    tvComplimentContent.setText(fullText);
                }
            }

            updateFavoriteButtonState();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportCardAsImage() {
        if (currentPraiseItem == null) return;
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            String quoteText = currentPraiseItem.getFormattedText();
            Bitmap cardBitmap = drawBeautifulPraiseCardBitmap(targetName, quoteText);

            if (cardBitmap != null) {
                showImagePreviewDialog(cardBitmap);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "卡片生成失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap drawBeautifulPraiseCardBitmap(String targetName, String quoteText) {
        int width = 1080;
        int height = 1480;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        // 1. Background Gradient
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int startColor = isDark ? Color.parseColor("#090D16") : Color.parseColor("#F1F5F9");
        int midColor = isDark ? Color.parseColor("#111827") : Color.parseColor("#E2E8F0");
        int endColor = isDark ? Color.parseColor("#1E293B") : Color.parseColor("#F8FAFC");
        LinearGradient bgGradient = new LinearGradient(0, 0, width, height, new int[]{startColor, midColor, endColor}, null, Shader.TileMode.CLAMP);
        bgPaint.setShader(bgGradient);
        canvas.drawRect(0, 0, width, height, bgPaint);

        // 2. Glass Card Container
        int cardMargin = 72;
        int cardTop = 180;
        int cardBottom = height - 160;
        RectF cardRect = new RectF(cardMargin, cardTop, width - cardMargin, cardBottom);

        Paint cardBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBgPaint.setStyle(Paint.Style.FILL);
        cardBgPaint.setColor(isDark ? Color.parseColor("#25FFFFFF") : Color.parseColor("#FAFFFFFF"));
        canvas.drawRoundRect(cardRect, 48, 48, cardBgPaint);

        Paint cardBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBorderPaint.setStyle(Paint.Style.STROKE);
        cardBorderPaint.setStrokeWidth(3f);
        cardBorderPaint.setColor(isDark ? Color.parseColor("#475569") : Color.parseColor("#CBD5E1"));
        canvas.drawRoundRect(cardRect, 48, 48, cardBorderPaint);

        // 3. Header Badge
        Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        badgePaint.setColor(Color.parseColor("#007AFF"));
        badgePaint.setTextSize(34f);
        badgePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("✦ 今日赞美 ✦", cardMargin + 60, cardTop + 100, badgePaint);

        // Target Name Display
        Paint namePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        namePaint.setColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        namePaint.setTextSize(56f);
        namePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText(targetName, cardMargin + 60, cardTop + 180, namePaint);

        // 4. Quote Text Layout
        TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        textPaint.setTextSize(44f);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        int maxTextWidth = width - (cardMargin + 60) * 2;
        StaticLayout staticLayout;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            staticLayout = StaticLayout.Builder.obtain(quoteText, 0, quoteText.length(), textPaint, maxTextWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(20f, 1.25f)
                    .build();
        } else {
            staticLayout = new StaticLayout(quoteText, textPaint, maxTextWidth, Layout.Alignment.ALIGN_NORMAL, 1.25f, 20f, false);
        }

        canvas.save();
        canvas.translate(cardMargin + 60, cardTop + 260);
        staticLayout.draw(canvas);
        canvas.restore();

        // 5. Card Footer (Date & Brand Tag)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        String dateStr = sdf.format(new Date());

        Paint footerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        footerPaint.setColor(isDark ? Color.parseColor("#94A3B8") : Color.parseColor("#64748B"));
        footerPaint.setTextSize(32f);
        canvas.drawText(dateStr, cardMargin + 60, cardBottom - 60, footerPaint);

        Paint brandPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        brandPaint.setColor(Color.parseColor("#007AFF"));
        brandPaint.setTextSize(32f);
        brandPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        brandPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("—— 来自「夸奖器」App", width - cardMargin - 60, cardBottom - 60, brandPaint);

        return bitmap;
    }

    private void showImagePreviewDialog(final Bitmap cardBitmap) {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 40, 48, 40);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        // Header
        RelativeLayout headerLayout = new RelativeLayout(this);
        TextView tvTitle = new TextView(this);
        tvTitle.setText("美图卡片预览 🎨");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        headerLayout.addView(tvTitle);
        layout.addView(headerLayout);

        // Image Preview Display
        ImageView imgPreview = new ImageView(this);
        imgPreview.setAdjustViewBounds(true);
        imgPreview.setImageBitmap(cardBitmap);
        
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        imgParams.topMargin = 24;
        imgParams.bottomMargin = 28;
        imgPreview.setLayoutParams(imgParams);
        layout.addView(imgPreview);

        // Action Buttons Row (Save to Gallery & Share)
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnSave = new TextView(this);
        btnSave.setText("保存到相册");
        btnSave.setTextColor(Color.WHITE);
        btnSave.setTextSize(14);
        btnSave.setTypeface(null, android.graphics.Typeface.BOLD);
        btnSave.setGravity(Gravity.CENTER);
        btnSave.setBackgroundResource(R.drawable.bg_glass_button);

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(0, 110, 1f);
        saveParams.rightMargin = 12;
        btnSave.setLayoutParams(saveParams);
        btnRow.addView(btnSave);

        TextView btnShare = new TextView(this);
        btnShare.setText("分享卡片");
        btnShare.setTextColor(Color.parseColor("#007AFF"));
        btnShare.setTextSize(14);
        btnShare.setTypeface(null, android.graphics.Typeface.BOLD);
        btnShare.setGravity(Gravity.CENTER);
        btnShare.setBackgroundResource(R.drawable.bg_glass_button_secondary);

        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, 110, 1f);
        shareParams.leftMargin = 12;
        btnShare.setLayoutParams(shareParams);
        btnRow.addView(btnShare);

        layout.addView(btnRow);

        dialog.setContentView(layout);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.7f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        btnSave.setOnClickListener(v -> {
            try {
                String title = "PraiseCard_" + System.currentTimeMillis();
                String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), cardBitmap, title, "来自夸奖器App的精美卡片");
                if (savedPath != null) {
                    Toast.makeText(MainActivity.this, R.string.toast_card_saved, Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "卡片已保存至相册！", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "保存失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnShare.setOnClickListener(v -> {
            try {
                String title = "PraiseCard_" + System.currentTimeMillis();
                String savedPath = MediaStore.Images.Media.insertImage(getContentResolver(), cardBitmap, title, "来自夸奖器App的精美卡片");
                if (savedPath != null) {
                    Uri imageUri = Uri.parse(savedPath);
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("image/*");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                    startActivity(Intent.createChooser(shareIntent, "分享美图卡片"));
                    dialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "分享失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void updateFavoriteButtonState() {
        if (currentPraiseItem == null) return;
        boolean isFav = FavoritesManager.getInstance(this).isFavorite(currentPraiseItem.getFormattedText());
        if (isFav) {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_filled);
            tvFavLabel.setText(R.string.btn_favorited);
        } else {
            ivFavIcon.setImageResource(R.drawable.ic_favorite_border);
            tvFavLabel.setText(R.string.btn_favorite);
        }
    }

    private void toggleFavoriteCurrent() {
        if (currentPraiseItem == null) return;
        FavoritesManager favManager = FavoritesManager.getInstance(this);
        boolean isFav = favManager.isFavorite(currentPraiseItem.getFormattedText());

        if (isFav) {
            favManager.removeFavorite(currentPraiseItem.getFormattedText());
            Toast.makeText(this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
        } else {
            favManager.addFavorite(currentPraiseItem);
            Toast.makeText(this, R.string.toast_favorited, Toast.LENGTH_SHORT).show();
        }
        updateFavoriteButtonState();
    }

    private void setupFavoritesTab() {
        rvFavorites.setLayoutManager(new LinearLayoutManager(this));
        favoritesAdapter = new FavoritesAdapter(null, new FavoritesAdapter.OnItemActionListener() {
            @Override
            public void onCopy(PraiseItem item) {
                copyTextToClipboard(item.getFormattedText());
            }

            @Override
            public void onShare(PraiseItem item) {
                shareText(item.getFormattedText());
            }

            @Override
            public void onDelete(PraiseItem item, int position) {
                FavoritesManager.getInstance(MainActivity.this).removeFavorite(item.getId());
                favoritesAdapter.removeItem(position);
                refreshFavoritesHeaderCount();
                updateFavoriteButtonState();
                Toast.makeText(MainActivity.this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onExportCard(PraiseItem item) {
                if (item == null) return;
                try {
                    String targetName = ThemeSettingsManager.getInstance(MainActivity.this).getTargetName();
                    String quoteText = item.getFormattedText();
                    Bitmap cardBitmap = drawBeautifulPraiseCardBitmap(targetName, quoteText);
                    if (cardBitmap != null) {
                        showImagePreviewDialog(cardBitmap);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "卡片生成失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        rvFavorites.setAdapter(favoritesAdapter);
        refreshFavoritesData();
    }

    private void refreshFavoritesData() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        favoritesAdapter.updateData(list);
        refreshFavoritesHeaderCount();
    }

    private void refreshFavoritesHeaderCount() {
        List<PraiseItem> list = FavoritesManager.getInstance(this).getFavorites();
        int count = list.size();
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvFavoritesSubtitle.setText(String.format("已为 %s 收藏 %d 条专属灵感", targetName, count));

        if (count == 0) {
            layoutFavoritesEmpty.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            layoutFavoritesEmpty.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }
    }

    private void setupSettingsTab() {
        loadSettingsData();

        btnSaveName.setOnClickListener(v -> {
            String newName = etTargetName.getText().toString().trim();
            if (newName.isEmpty()) {
                newName = ThemeSettingsManager.DEFAULT_TARGET;
            }
            ThemeSettingsManager.getInstance(this).setTargetName(newName);
            tvTargetName.setText(newName);
            generateNewCompliment(false);
            Toast.makeText(this, String.format(getString(R.string.toast_name_updated), newName), Toast.LENGTH_SHORT).show();
        });

        btnResetName.setOnClickListener(v -> showCustomNameHistoryDialog());

        rgTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int mode = ThemeSettingsManager.THEME_SYSTEM;
            if (checkedId == R.id.rb_theme_light) {
                mode = ThemeSettingsManager.THEME_LIGHT;
            } else if (checkedId == R.id.rb_theme_dark) {
                mode = ThemeSettingsManager.THEME_DARK;
            } else if (checkedId == R.id.rb_theme_system) {
                mode = ThemeSettingsManager.THEME_SYSTEM;
            }

            ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
            if (settingsManager.getThemeMode() != mode) {
                settingsManager.setThemeMode(mode);
                recreate();
            }
        });

        btnClearFavorites.setOnClickListener(v -> showClearFavoritesDialog());

        View btnTelegram = findViewById(R.id.btn_author_telegram);
        if (btnTelegram != null) {
            btnTelegram.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/shuilin791"));
                    startActivity(intent);
                } catch (Exception e) {
                    copyTextToClipboard("@shuilin791");
                    Toast.makeText(MainActivity.this, "已复制作者 Telegram：@shuilin791", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // Seamless 100% Custom Liquid Glass Name History Dialog (Zero System Window Box!)
    private void showCustomNameHistoryDialog() {
        boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        List<String> historyList = settingsManager.getNameHistory();

        if (historyList.isEmpty()) {
            Toast.makeText(this, "暂无历史名称记录", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(64, 56, 64, 56);
        layout.setBackgroundResource(isDark ? R.drawable.bg_dialog_card_dark : R.drawable.bg_dialog_card_light);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("名称历史记录");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F"));
        layout.addView(tvTitle);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scrollParams.topMargin = 24;
        scrollView.setLayoutParams(scrollParams);

        LinearLayout historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(LinearLayout.VERTICAL);

        for (String nameItem : historyList) {
            TextView tvItem = new TextView(this);
            tvItem.setText(nameItem);
            tvItem.setTextSize(15);
            tvItem.setTypeface(null, android.graphics.Typeface.BOLD);
            tvItem.setTextColor(isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#007AFF"));
            tvItem.setBackgroundResource(isDark ? R.drawable.bg_dialog_item_dark : R.drawable.bg_dialog_item_light);
            tvItem.setPadding(32, 26, 32, 26);

            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            itemParams.bottomMargin = 14;
            tvItem.setLayoutParams(itemParams);

            tvItem.setOnClickListener(v -> {
                etTargetName.setText(nameItem);
                settingsManager.setTargetName(nameItem);
                tvTargetName.setText(nameItem);
                generateNewCompliment(false);
                Toast.makeText(MainActivity.this, String.format(getString(R.string.toast_name_updated), nameItem), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            historyContainer.addView(tvItem);
        }

        scrollView.addView(historyContainer);
        layout.addView(scrollView);

        dialog.setContentView(layout);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setDimAmount(0.65f);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setAttributes(lp);
        }

        dialog.show();
    }

    private void loadSettingsData() {
        ThemeSettingsManager settingsManager = ThemeSettingsManager.getInstance(this);
        etTargetName.setText(settingsManager.getTargetName());

        int mode = settingsManager.getThemeMode();
        if (mode == ThemeSettingsManager.THEME_LIGHT) {
            rbThemeLight.setChecked(true);
        } else if (mode == ThemeSettingsManager.THEME_DARK) {
            rbThemeDark.setChecked(true);
        } else {
            rbThemeSystem.setChecked(true);
        }
    }

    private void showClearFavoritesDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_clear_confirm_title)
                .setMessage(R.string.settings_clear_confirm_msg)
                .setPositiveButton(R.string.settings_clear_confirm_ok, (dialog, which) -> {
                    FavoritesManager.getInstance(MainActivity.this).clearAllFavorites();
                    refreshFavoritesData();
                    updateFavoriteButtonState();
                    Toast.makeText(MainActivity.this, R.string.toast_cleared, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.settings_clear_confirm_cancel, null)
                .show();
    }

    private void copyTextToClipboard(String text) {
        if (text == null || text.isEmpty()) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("PraiseText", text);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void shareText(String text) {
        if (text == null || text.isEmpty()) return;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String shareContent = "【专属夸奖灵感】\n" + text + "\n\n—— 来自 夸奖器 App";
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent);
        startActivity(Intent.createChooser(shareIntent, "分享夸奖灵感"));
    }
}
