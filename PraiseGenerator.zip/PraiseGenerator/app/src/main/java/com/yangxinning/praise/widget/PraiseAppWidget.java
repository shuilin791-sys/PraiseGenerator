package com.yangxinning.praise.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.yangxinning.praise.MainActivity;
import com.yangxinning.praise.R;
import com.yangxinning.praise.manager.PraiseManager;
import com.yangxinning.praise.manager.ThemeSettingsManager;
import com.yangxinning.praise.model.PraiseItem;

public class PraiseAppWidget extends AppWidgetProvider {

    public static final String ACTION_REFRESH_WIDGET = "com.yangxinning.praise.ACTION_REFRESH_WIDGET";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH_WIDGET.equals(intent.getAction())) {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            ComponentName thisWidget = new ComponentName(context, PraiseAppWidget.class);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
            onUpdate(context, appWidgetManager, appWidgetIds);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_praise);

        String targetName = ThemeSettingsManager.getInstance(context).getTargetName();
        PraiseItem item = PraiseManager.getInstance().generateRandomPraise(targetName);

        views.setTextViewText(R.id.widget_tv_target, "✦ 每日赞美 · " + targetName);
        views.setTextViewText(R.id.widget_tv_content, item.getFormattedText());

        // Refresh action
        Intent refreshIntent = new Intent(context, PraiseAppWidget.class);
        refreshIntent.setAction(ACTION_REFRESH_WIDGET);
        PendingIntent refreshPendingIntent = PendingIntent.getBroadcast(
                context, 0, refreshIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_btn_refresh, refreshPendingIntent);

        // Open App action
        Intent appIntent = new Intent(context, MainActivity.class);
        PendingIntent appPendingIntent = PendingIntent.getActivity(
                context, 0, appIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, appPendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
