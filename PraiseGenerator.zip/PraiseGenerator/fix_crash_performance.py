import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Optimized FavoritesManager with in-memory caching
fav_manager_code = """package com.yangxinning.praise.manager;

import android.content.Context;
import android.content.SharedPreferences;

import com.yangxinning.praise.model.PraiseItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FavoritesManager {

    private static final String PREF_NAME = "yang_xinning_praise_favs";
    private static final String KEY_FAVORITES_JSON = "favorites_list_json";
    private static FavoritesManager instance;
    private final SharedPreferences prefs;
    private List<PraiseItem> cachedFavorites;

    private FavoritesManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        loadFromPrefs();
    }

    public static synchronized FavoritesManager getInstance(Context context) {
        if (instance == null) {
            instance = new FavoritesManager(context);
        }
        return instance;
    }

    private synchronized void loadFromPrefs() {
        cachedFavorites = new ArrayList<>();
        String jsonStr = prefs.getString(KEY_FAVORITES_JSON, "[]");
        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                PraiseItem item = new PraiseItem();
                item.setId(obj.optString("id"));
                item.setRawQuote(obj.optString("rawQuote"));
                item.setFormattedText(obj.optString("formattedText"));
                item.setTargetName(obj.optString("targetName"));
                item.setTimestamp(obj.optLong("timestamp"));
                cachedFavorites.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized List<PraiseItem> getFavorites() {
        if (cachedFavorites == null) {
            loadFromPrefs();
        }
        return new ArrayList<>(cachedFavorites);
    }

    public synchronized boolean isFavorite(String text) {
        if (text == null) return false;
        if (cachedFavorites == null) {
            loadFromPrefs();
        }
        for (PraiseItem item : cachedFavorites) {
            if (text.equals(item.getFormattedText())) {
                return true;
            }
        }
        return false;
    }

    public synchronized boolean addFavorite(PraiseItem item) {
        if (item == null || isFavorite(item.getFormattedText())) {
            return false;
        }
        cachedFavorites.add(0, item);
        saveFavoritesAsync();
        return true;
    }

    public synchronized boolean removeFavorite(String idOrText) {
        if (idOrText == null) return false;
        if (cachedFavorites == null) {
            loadFromPrefs();
        }
        boolean removed = false;
        for (int i = cachedFavorites.size() - 1; i >= 0; i--) {
            PraiseItem item = cachedFavorites.get(i);
            if (idOrText.equals(item.getId()) || idOrText.equals(item.getFormattedText())) {
                cachedFavorites.remove(i);
                removed = true;
            }
        }
        if (removed) {
            saveFavoritesAsync();
        }
        return removed;
    }

    public synchronized void clearAllFavorites() {
        if (cachedFavorites != null) {
            cachedFavorites.clear();
        }
        prefs.edit().remove(KEY_FAVORITES_JSON).apply();
    }

    private synchronized void saveFavoritesAsync() {
        try {
            JSONArray array = new JSONArray();
            for (PraiseItem item : cachedFavorites) {
                JSONObject obj = new JSONObject();
                obj.put("id", item.getId());
                obj.put("rawQuote", item.getRawQuote());
                obj.put("formattedText", item.getFormattedText());
                obj.put("targetName", item.getTargetName());
                obj.put("timestamp", item.getTimestamp());
                array.put(obj);
            }
            prefs.edit().putString(KEY_FAVORITES_JSON, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
"""

with open(f"{package_path}/manager/FavoritesManager.java", "w", encoding="utf-8") as f:
    f.write(fav_manager_code)

# 2. Optimized MainActivity with click debounce & animation cleanup
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    content = f.read()

# Replace setupPraiseTab & generateNewCompliment methods to include debounce and clearAnimation
old_praise_setup = """    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        btnGenerateCompliment.setOnClickListener(v -> generateNewCompliment(true));
        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
    }

    private void generateNewCompliment(boolean animate) {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);

        if (animate) {
            Animation popAnim = AnimationUtils.loadAnimation(this, R.anim.card_pop);
            cardComplimentWrapper.startAnimation(popAnim);
        }

        tvComplimentContent.setText(currentPraiseItem.getFormattedText());
        updateFavoriteButtonState();
    }"""

new_praise_setup = """    private long lastGenerateClickTime = 0;

    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return; // Throttle ultra-fast rapid clicks (150ms debounce)
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
    }

    private void generateNewCompliment(boolean animate) {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);

        if (animate) {
            cardComplimentWrapper.clearAnimation();
            Animation popAnim = AnimationUtils.loadAnimation(this, R.anim.card_pop);
            cardComplimentWrapper.startAnimation(popAnim);
        }

        tvComplimentContent.setText(currentPraiseItem.getFormattedText());
        updateFavoriteButtonState();
    }"""

content = content.replace(old_praise_setup, new_praise_setup)
with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(content)

print("FavoritesManager and MainActivity optimized for high-speed clicking stability.")
