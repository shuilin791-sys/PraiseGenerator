import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"

layout_praise_xml = """<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:scrollbars="none"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fillViewport="true"
    android:paddingStart="20dp"
    android:paddingTop="48dp"
    android:paddingEnd="20dp"
    android:paddingBottom="100dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center_horizontal"
        android:orientation="vertical">

        <!-- Header (Subject Name & Clean Subtitle) -->
        <TextView
            android:id="@+id/tv_target_name"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/default_target_name"
            android:textColor="?attr/colorOnBackground"
            android:textSize="34sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tv_subtitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="4dp"
            android:text="@string/subtitle_main"
            android:textColor="#6E6E73"
            android:textSize="14sp" />

        <!-- Single-Layer Liquid Glass Compliment Card -->
        <LinearLayout
            android:id="@+id/card_compliment_wrapper"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="28dp"
            android:background="@drawable/bg_liquid_glass_card"
            android:orientation="vertical"
            android:padding="24dp">

            <!-- Badge & Sparkle -->
            <RelativeLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content">

                <TextView
                    android:id="@+id/tv_quote_badge"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_alignParentStart="true"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:paddingStart="12dp"
                    android:paddingTop="4dp"
                    android:paddingEnd="12dp"
                    android:paddingBottom="4dp"
                    android:text="今日赞美"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <ImageView
                    android:layout_width="24dp"
                    android:layout_height="24dp"
                    android:layout_alignParentEnd="true"
                    android:contentDescription="Sparkle"
                    android:src="@drawable/ic_sparkle"
                    app:tint="#007AFF" />
            </RelativeLayout>

            <!-- Quote Text -->
            <TextView
                android:id="@+id/tv_compliment_content"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="20dp"
                android:layout_marginBottom="24dp"
                android:lineSpacingExtra="8dp"
                android:minLines="4"
                android:text="点击下方按钮，生成专属于你的高质感夸奖语录..."
                android:textColor="?attr/colorOnBackground"
                android:textSize="18sp"
                android:textStyle="bold" />

            <!-- Action Bar (Favorite, Export Card, Copy, Share) -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:gravity="center_vertical"
                android:orientation="horizontal">

                <!-- Favorite Button -->
                <LinearLayout
                    android:id="@+id/btn_action_favorite"
                    android:layout_width="0dp"
                    android:layout_height="42dp"
                    android:layout_marginEnd="4dp"
                    android:layout_weight="1"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:orientation="horizontal"
                    android:paddingStart="4dp"
                    android:paddingEnd="4dp">

                    <ImageView
                        android:id="@+id/iv_fav_icon"
                        android:layout_width="16dp"
                        android:layout_height="16dp"
                        android:contentDescription="@string/btn_favorite"
                        android:src="@drawable/ic_favorite_border"
                        app:tint="#FF2D55" />

                    <TextView
                        android:id="@+id/tv_fav_label"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="3dp"
                        android:text="@string/btn_favorite"
                        android:textColor="#FF2D55"
                        android:textSize="11sp"
                        android:textStyle="bold" />
                </LinearLayout>

                <!-- Export Card Button -->
                <LinearLayout
                    android:id="@+id/btn_action_export_card"
                    android:layout_width="0dp"
                    android:layout_height="42dp"
                    android:layout_marginStart="2dp"
                    android:layout_marginEnd="2dp"
                    android:layout_weight="1"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:orientation="horizontal"
                    android:paddingStart="4dp"
                    android:paddingEnd="4dp">

                    <ImageView
                        android:layout_width="16dp"
                        android:layout_height="16dp"
                        android:contentDescription="@string/btn_export_card"
                        android:src="@drawable/ic_sparkle"
                        app:tint="#007AFF" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="3dp"
                        android:text="@string/btn_export_card"
                        android:textColor="#007AFF"
                        android:textSize="11sp"
                        android:textStyle="bold" />
                </LinearLayout>

                <!-- Copy Button -->
                <LinearLayout
                    android:id="@+id/btn_action_copy"
                    android:layout_width="0dp"
                    android:layout_height="42dp"
                    android:layout_marginStart="2dp"
                    android:layout_marginEnd="2dp"
                    android:layout_weight="1"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:orientation="horizontal"
                    android:paddingStart="4dp"
                    android:paddingEnd="4dp">

                    <ImageView
                        android:layout_width="16dp"
                        android:layout_height="16dp"
                        android:contentDescription="@string/btn_copy"
                        android:src="@drawable/ic_copy"
                        app:tint="#007AFF" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="3dp"
                        android:text="复制"
                        android:textColor="#007AFF"
                        android:textSize="11sp"
                        android:textStyle="bold" />
                </LinearLayout>

                <!-- Share Button -->
                <LinearLayout
                    android:id="@+id/btn_action_share"
                    android:layout_width="0dp"
                    android:layout_height="42dp"
                    android:layout_marginStart="4dp"
                    android:layout_weight="1"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:orientation="horizontal"
                    android:paddingStart="4dp"
                    android:paddingEnd="4dp">

                    <ImageView
                        android:layout_width="16dp"
                        android:layout_height="16dp"
                        android:contentDescription="@string/btn_share"
                        android:src="@drawable/ic_share"
                        app:tint="#007AFF" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="3dp"
                        android:text="分享"
                        android:textColor="#007AFF"
                        android:textSize="11sp"
                        android:textStyle="bold" />
                </LinearLayout>

            </LinearLayout>

        </LinearLayout>

        <!-- Prominent Generate Button -->
        <FrameLayout
            android:id="@+id/btn_generate_compliment"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="24dp"
            android:background="@drawable/bg_glass_button"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="center"
                android:gravity="center"
                android:orientation="horizontal">

                <ImageView
                    android:layout_width="22dp"
                    android:layout_height="22dp"
                    android:contentDescription="Magic"
                    android:src="@drawable/ic_sparkle"
                    app:tint="#FFFFFF" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:text="@string/btn_generate"
                    android:textColor="#FFFFFF"
                    android:textSize="16sp"
                    android:textStyle="bold" />
            </LinearLayout>

        </FrameLayout>

    </LinearLayout>

</ScrollView>
"""

with open(f"{project_dir}/app/src/main/res/layout/layout_tab_praise.xml", "w", encoding="utf-8") as f:
    f.write(layout_praise_xml)

print("layout_tab_praise.xml updated with btn_action_export_card ID.")
