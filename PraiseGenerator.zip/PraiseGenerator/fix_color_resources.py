import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"

# 1. Complete colors.xml containing all referenced color names
colors_xml = """<resources>
    <!-- iOS Brand Palette -->
    <color name="ios_blue">#007AFF</color>
    <color name="ios_blue_dark">#0A84FF</color>
    <color name="ios_purple">#AF52DE</color>
    <color name="ios_indigo">#5856D6</color>
    <color name="ios_pink">#FF2D55</color>
    <color name="ios_cyan">#32ADE6</color>

    <color name="text_primary_light">#1D1D1F</color>
    <color name="text_secondary_light">#6E6E73</color>
    
    <color name="text_primary_dark">#F5F5F7</color>
    <color name="text_secondary_dark">#A1A1A6</color>

    <color name="transparent">#00000000</color>
</resources>
"""

# 2. Clean themes.xml (Light Theme)
themes_xml = """<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.YangXinningPraise" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/ios_blue</item>
        <item name="colorPrimaryVariant">@color/ios_indigo</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        
        <item name="colorSecondary">@color/ios_purple</item>
        <item name="colorSecondaryVariant">@color/ios_pink</item>
        <item name="colorOnSecondary">#FFFFFF</item>
        
        <item name="android:statusBarColor">@color/transparent</item>
        <item name="android:navigationBarColor">@color/transparent</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:windowLightNavigationBar">true</item>
    </style>
</resources>
"""

# 3. Clean values-night/themes.xml (Dark Theme)
themes_night_xml = """<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.YangXinningPraise" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/ios_blue_dark</item>
        <item name="colorPrimaryVariant">@color/ios_indigo</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        
        <item name="colorSecondary">@color/ios_purple</item>
        <item name="colorSecondaryVariant">@color/ios_pink</item>
        <item name="colorOnSecondary">#FFFFFF</item>
        
        <item name="android:statusBarColor">@color/transparent</item>
        <item name="android:navigationBarColor">@color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:windowLightNavigationBar">false</item>
    </style>
</resources>
"""

with open(f"{project_dir}/app/src/main/res/values/colors.xml", "w", encoding="utf-8") as f:
    f.write(colors_xml)

with open(f"{project_dir}/app/src/main/res/values/themes.xml", "w", encoding="utf-8") as f:
    f.write(themes_xml)

with open(f"{project_dir}/app/src/main/res/values-night/themes.xml", "w", encoding="utf-8") as f:
    f.write(themes_night_xml)

print("Colors and themes XML files fixed successfully.")
