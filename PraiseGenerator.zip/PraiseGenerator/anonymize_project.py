import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update strings.xml (default target -> Alex)
strings_xml = """<resources>
    <string name="app_name">夸奖器</string>
    <string name="default_target_name">Alex</string>
    <string name="subtitle_main">专属灵感与夸奖</string>
    <string name="tab_praise">夸夸</string>
    <string name="tab_favorites">收藏</string>
    <string name="tab_settings">设置</string>
    
    <string name="btn_generate">生成专属夸奖</string>
    <string name="btn_favorite">收藏</string>
    <string name="btn_favorited">已收藏</string>
    <string name="btn_copy">复制夸奖</string>
    <string name="btn_share">分享灵感</string>
    
    <string name="favorites_title">精选夸奖收藏箱</string>
    <string name="favorites_subtitle">记录属于 %1$s 的每一个闪光时刻</string>
    <string name="favorites_empty_title">暂无收藏的夸奖</string>
    <string name="favorites_empty_desc">点击主页夸奖卡片下方的“收藏”按钮，将精彩语录保存在这里吧！</string>
    
    <string name="settings_title">系统偏好设置</string>
    <string name="settings_target_section">夸奖对象自定义</string>
    <string name="settings_target_hint">请输入要夸奖的对象姓名</string>
    <string name="settings_target_save">保存姓名</string>
    <string name="settings_target_reset">重置为 Alex</string>
    
    <string name="settings_theme_section">外观与主题风格</string>
    <string name="settings_theme_light">浅色模式 (Light Mode)</string>
    <string name="settings_theme_dark">深色模式 (Dark Liquid)</string>
    <string name="settings_theme_system">跟随系统 (Auto Adapt)</string>
    
    <string name="settings_data_section">数据与隐私管理</string>
    <string name="settings_clear_favorites">清空所有收藏</string>
    <string name="settings_clear_confirm_title">确认清空？</string>
    <string name="settings_clear_confirm_msg">此操作将彻底删除所有已保存的夸奖语录，无法恢复。</string>
    <string name="settings_clear_confirm_ok">确认清空</string>
    <string name="settings_clear_confirm_cancel">取消</string>
    
    <string name="settings_about_section">关于应用</string>
    <string name="settings_about_app_desc">夸奖器 是一款精美优雅的高质感原生 Android 夸奖生成工具。内置 100+ 条精心撰写的专属夸奖语录，带来流畅顺滑的交互体验。</string>
    <string name="settings_version">版本 v1.0.0 (Build 2026.11)</string>
    
    <string name="toast_copied">夸奖语录已复制到剪贴板！</string>
    <string name="toast_favorited">已成功加入收藏！</string>
    <string name="toast_unfavorited">已取消收藏</string>
    <string name="toast_cleared">所有收藏已成功清空</string>
    <string name="toast_name_updated">夸奖对象已更新为：%1$s</string>
</resources>
"""

with open(f"{project_dir}/app/src/main/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(strings_xml)

# 2. Update ThemeSettingsManager.java (DEFAULT_TARGET = "Alex")
theme_settings_file = f"{package_path}/manager/ThemeSettingsManager.java"
with open(theme_settings_file, "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace('public static final String DEFAULT_TARGET = "Yang Xinning";', 'public static final String DEFAULT_TARGET = "Alex";')
with open(theme_settings_file, "w", encoding="utf-8") as f:
    f.write(content)

# 3. Update PraiseItem.java (default -> "Alex")
praise_item_file = f"{package_path}/model/PraiseItem.java"
with open(praise_item_file, "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace('"Yang Xinning"', '"Alex"')
with open(praise_item_file, "w", encoding="utf-8") as f:
    f.write(content)

# 4. Update MainActivity.java (share title -> "夸奖器")
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace('【Yang Xinning 专属夸奖】', '【专属夸奖灵感】')
with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(content)

# 5. Update README.md (replace Yang Xinning with Alex)
readme_content = """# 夸奖器 (Praise Generator for Android)

一款高质感原生 Android 夸奖语录生成应用。基于 Apple iOS Liquid Glass（液态玻璃）设计语言，采用纯 Java + XML 原生架构开发。

![Android](https://img.shields.io/badge/Platform-Android-green.svg)
![Language](https://img.shields.io/badge/Language-Java-orange.svg)
![UI Design](https://img.shields.io/badge/Design-Liquid%20Glass-blue.svg)
![License](https://img.shields.io/badge/License-MIT-brightgreen.svg)

---

## ✨ 核心功能亮点

- **105+ 原创高质感语录**：涵盖智慧洞察、逻辑思维、审美品味、行动力与人格魅力。
- **智能防重复队列**：内置内存历史记录算法，确保高频点击生成不重样。
- **一键互动体验**：支持夸奖语录的秒级收藏、一键复制到剪贴板与唤起系统原生分享。
- **本地持久化收藏箱**：收藏语录永久保存在本地存储中，随时查阅与管理。
- **自定义夸奖对象与主题**：支持自定义夸奖姓名（默认 **Alex**，可在设置中自由修改），内置浅色模式 (Light Mode) 与深色模式 (Dark Liquid) 实时切换。
- **零闪退与高频点击优化**：采用 `ViewPropertyAnimator` 渐变动画与内存一级缓存，性能极致稳定。

---

## 🎨 视觉与设计特色

- **标志性悬浮胶囊导航栏**：悬浮于屏幕底部的半透明液态玻璃胶囊 Navigation Bar，高对比度清晰图标与流体高光。
- **单层微光玻璃卡片**：去除沉闷黑影，结合高透玻璃材质与自然渐变背景。
- **真实深浅色双模式**：
  - **浅色模式**：清透高雅的 iOS 极简白蓝渐变。
  - **深色模式**：深邃高级的夜蓝黑耀玻璃与亮白字体对比。

---

## 🛠 技术栈与架构

- **开发语言**：Java (JDK 8 / 11)
- **UI 布局**：Android Native XML Layouts + Vector Drawables
- **兼容性**：完全兼容 Android Studio & 手机端 **CodeAssist** IDE
- **最小 SDK 支持**：API 24 (Android 7.0+)
- **目标 SDK**：API 34 (Android 14)

---

## 🚀 编译与运行说明

### 在 Android Studio 中编译：
1. 克隆本项目：
   ```bash
   git clone https://github.com/YOUR_USERNAME/PraiseGenerator.git
   ```
2. 打开 Android Studio，点击 `File -> Open` 选择项目根目录。
3. 等待 Gradle 同步完成后，点击右上角的 **Run 'app'** (▶) 即可编译并安装。

### 在手机端 CodeAssist 中编译：
1. 下载解压 zip 文件或使用 Git 导入 CodeAssist。
2. 打开项目选择 **兼容模式**。
3. 点击右上角 **`▶` ➔ `Run Debug · app`** 即可在手机上直接构建 APK！

---

## 📄 开源许可证

本项目基于 [MIT License](LICENSE) 开源。
"""

with open(f"{project_dir}/README.md", "w", encoding="utf-8") as f:
    f.write(readme_content)

print("Project fully anonymized: default name changed to Alex.")
