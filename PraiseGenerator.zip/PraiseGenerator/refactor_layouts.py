import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"

# 1. activity_main.xml
activity_main_xml = """<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/root_layout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@drawable/bg_dynamic_gradient_light"
    android:fitsSystemWindows="true">

    <!-- Content Container -->
    <ViewFlipper
        android:id="@+id/view_flipper"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:inAnimation="@anim/fade_in"
        android:outAnimation="@anim/fade_out">

        <include layout="@layout/layout_tab_praise" />
        <include layout="@layout/layout_tab_favorites" />
        <include layout="@layout/layout_tab_settings" />

    </ViewFlipper>

    <!-- Floating Liquid Glass Capsule Nav Bar -->
    <LinearLayout
        android:id="@+id/floating_nav_bar"
        android:layout_width="match_parent"
        android:layout_height="64dp"
        android:layout_alignParentBottom="true"
        android:layout_marginStart="24dp"
        android:layout_marginEnd="24dp"
        android:layout_marginBottom="24dp"
        android:background="@drawable/bg_liquid_glass_nav"
        android:elevation="12dp"
        android:orientation="horizontal"
        android:padding="6dp">

        <!-- Tab 1: Praise -->
        <LinearLayout
            android:id="@+id/nav_item_praise"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:background="@drawable/bg_nav_item_selected"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center"
            android:orientation="vertical">

            <ImageView
                android:id="@+id/nav_icon_praise"
                android:layout_width="22dp"
                android:layout_height="22dp"
                android:contentDescription="@string/tab_praise"
                android:src="@drawable/ic_tab_praise"
                app:tint="#FFFFFF" />

            <TextView
                android:id="@+id/nav_text_praise"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="2dp"
                android:text="@string/tab_praise"
                android:textColor="#FFFFFF"
                android:textSize="11sp"
                android:textStyle="bold" />
        </LinearLayout>

        <!-- Tab 2: Favorites -->
        <LinearLayout
            android:id="@+id/nav_item_favorites"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center"
            android:orientation="vertical">

            <ImageView
                android:id="@+id/nav_icon_favorites"
                android:layout_width="22dp"
                android:layout_height="22dp"
                android:contentDescription="@string/tab_favorites"
                android:src="@drawable/ic_tab_favorite"
                app:tint="#616161" />

            <TextView
                android:id="@+id/nav_text_favorites"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="2dp"
                android:text="@string/tab_favorites"
                android:textColor="#616161"
                android:textSize="11sp"
                android:textStyle="bold" />
        </LinearLayout>

        <!-- Tab 3: Settings -->
        <LinearLayout
            android:id="@+id/nav_item_settings"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center"
            android:orientation="vertical">

            <ImageView
                android:id="@+id/nav_icon_settings"
                android:layout_width="22dp"
                android:layout_height="22dp"
                android:contentDescription="@string/tab_settings"
                android:src="@drawable/ic_tab_settings"
                app:tint="#616161" />

            <TextView
                android:id="@+id/nav_text_settings"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="2dp"
                android:text="@string/tab_settings"
                android:textColor="#616161"
                android:textSize="11sp"
                android:textStyle="bold" />
        </LinearLayout>

    </LinearLayout>

</RelativeLayout>
"""

# 2. layout_tab_praise.xml (Clean Header & Single-layer Liquid Glass Card)
layout_tab_praise_xml = """<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fillViewport="true"
    android:paddingStart="20dp"
    android:paddingTop="48dp"
    android:paddingEnd="20dp"
    android:paddingBottom="100dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center_horizontal"
        android:orientation="vertical">

        <!-- Clean Header (Subject Name & Subtitle Only) -->
        <TextView
            android:id="@+id/tv_target_name"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/default_target_name"
            android:textColor="?attr/colorOnBackground"
            android:textSize="34sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tv_subtitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="4dp"
            android:text="@string/subtitle_main"
            android:textColor="#6E6E73"
            android:textSize="14sp" />

        <!-- Single-Layer Liquid Glass Compliment Card -->
        <androidx.cardview.widget.CardView
            android:id="@+id/card_compliment_wrapper"
            style="@style/Widget.GlassCard"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="28dp"
            app:cardBackgroundColor="@color/transparent"
            app:cardElevation="8dp">

            <LinearLayout
                android:id="@+id/card_compliment_inner"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_liquid_glass_card"
                android:orientation="vertical"
                android:padding="24dp">

                <!-- Badge & Sparkle -->
                <RelativeLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content">

                    <TextView
                        android:id="@+id/tv_quote_badge"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_alignParentStart="true"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:paddingStart="12dp"
                        android:paddingTop="4dp"
                        android:paddingEnd="12dp"
                        android:paddingBottom="4dp"
                        android:text="今日赞美"
                        android:textColor="#007AFF"
                        android:textSize="12sp"
                        android:textStyle="bold" />

                    <ImageView
                        android:layout_width="24dp"
                        android:layout_height="24dp"
                        android:layout_alignParentEnd="true"
                        android:contentDescription="Sparkle"
                        android:src="@drawable/ic_sparkle"
                        app:tint="#007AFF" />
                </RelativeLayout>

                <!-- Quote Text -->
                <TextView
                    android:id="@+id/tv_compliment_content"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="20dp"
                    android:layout_marginBottom="24dp"
                    android:lineSpacingExtra="8dp"
                    android:minLines="4"
                    android:text="点击下方按钮，生成专属于你的高质感夸奖语录..."
                    android:textColor="?attr/colorOnBackground"
                    android:textSize="18sp"
                    android:textStyle="bold" />

                <!-- Action Bar (Favorite, Copy, Share) -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:gravity="center_vertical"
                    android:orientation="horizontal">

                    <!-- Favorite Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_favorite"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginEnd="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:id="@+id/iv_fav_icon"
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_favorite"
                            android:src="@drawable/ic_favorite_border"
                            app:tint="#FF2D55" />

                        <TextView
                            android:id="@+id/tv_fav_label"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="@string/btn_favorite"
                            android:textColor="#FF2D55"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Copy Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_copy"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="4dp"
                        android:layout_marginEnd="4dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_copy"
                            android:src="@drawable/ic_copy"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="复制"
                            android:textColor="#007AFF"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                    <!-- Share Button -->
                    <LinearLayout
                        android:id="@+id/btn_action_share"
                        android:layout_width="0dp"
                        android:layout_height="42dp"
                        android:layout_marginStart="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:orientation="horizontal"
                        android:paddingStart="8dp"
                        android:paddingEnd="8dp">

                        <ImageView
                            android:layout_width="18dp"
                            android:layout_height="18dp"
                            android:contentDescription="@string/btn_share"
                            android:src="@drawable/ic_share"
                            app:tint="#007AFF" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="4dp"
                            android:text="分享"
                            android:textColor="#007AFF"
                            android:textSize="12sp"
                            android:textStyle="bold" />
                    </LinearLayout>

                </LinearLayout>

            </LinearLayout>

        </androidx.cardview.widget.CardView>

        <!-- Prominent Generate Button -->
        <FrameLayout
            android:id="@+id/btn_generate_compliment"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="28dp"
            android:background="@drawable/bg_glass_button"
            android:clickable="true"
            android:elevation="6dp"
            android:focusable="true">

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="center"
                android:gravity="center"
                android:orientation="horizontal">

                <ImageView
                    android:layout_width="22dp"
                    android:layout_height="22dp"
                    android:contentDescription="Magic"
                    android:src="@drawable/ic_sparkle"
                    app:tint="#FFFFFF" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:text="@string/btn_generate"
                    android:textColor="#FFFFFF"
                    android:textSize="16sp"
                    android:textStyle="bold" />
            </LinearLayout>

        </FrameLayout>

    </LinearLayout>

</ScrollView>
"""

# 3. layout_tab_favorites.xml
layout_tab_favorites_xml = """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:paddingStart="20dp"
    android:paddingTop="48dp"
    android:paddingEnd="20dp"
    android:paddingBottom="100dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/favorites_title"
        android:textColor="?attr/colorOnBackground"
        android:textSize="28sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/tv_favorites_subtitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="4dp"
        android:text="已收藏 0 条灵感夸奖"
        android:textColor="#6E6E73"
        android:textSize="14sp" />

    <LinearLayout
        android:id="@+id/layout_favorites_empty"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:gravity="center"
        android:orientation="vertical"
        android:visibility="gone">

        <ImageView
            android:layout_width="64dp"
            android:layout_height="64dp"
            android:contentDescription="Empty"
            android:src="@drawable/ic_favorite_border"
            app:tint="#007AFF" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:text="@string/favorites_empty_title"
            android:textColor="?attr/colorOnBackground"
            android:textSize="17sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="260dp"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:gravity="center"
            android:lineSpacingExtra="4dp"
            android:text="@string/favorites_empty_desc"
            android:textColor="#6E6E73"
            android:textSize="13sp" />
    </LinearLayout>

    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/rv_favorites"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_marginTop="16dp"
        android:layout_weight="1"
        android:clipToPadding="false"
        android:scrollbars="vertical" />

</LinearLayout>
"""

# 4. layout_tab_settings.xml
layout_tab_settings_xml = """<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fillViewport="true"
    android:paddingStart="20dp"
    android:paddingTop="48dp"
    android:paddingEnd="20dp"
    android:paddingBottom="100dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/settings_title"
            android:textColor="?attr/colorOnBackground"
            android:textSize="28sp"
            android:textStyle="bold" />

        <!-- Target Name -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/settings_target_section"
            android:textColor="#007AFF"
            android:textSize="13sp"
            android:textStyle="bold" />

        <androidx.cardview.widget.CardView
            style="@style/Widget.GlassCard"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            app:cardBackgroundColor="@color/transparent"
            app:cardElevation="6dp">

            <LinearLayout
                android:id="@+id/card_settings_target"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_liquid_glass_card"
                android:orientation="vertical"
                android:padding="16dp">

                <EditText
                    android:id="@+id/et_target_name"
                    android:layout_width="match_parent"
                    android:layout_height="48dp"
                    android:background="@drawable/bg_glass_input"
                    android:hint="@string/settings_target_hint"
                    android:inputType="textPersonName"
                    android:maxLines="1"
                    android:paddingStart="16dp"
                    android:paddingEnd="16dp"
                    android:textColor="?attr/colorOnBackground"
                    android:textColorHint="#6E6E73"
                    android:textSize="15sp" />

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    android:orientation="horizontal">

                    <TextView
                        android:id="@+id/btn_save_name"
                        android:layout_width="0dp"
                        android:layout_height="40dp"
                        android:layout_marginEnd="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:text="@string/settings_target_save"
                        android:textColor="#FFFFFF"
                        android:textSize="13sp"
                        android:textStyle="bold" />

                    <TextView
                        android:id="@+id/btn_reset_name"
                        android:layout_width="0dp"
                        android:layout_height="40dp"
                        android:layout_marginStart="6dp"
                        android:layout_weight="1"
                        android:background="@drawable/bg_glass_button_secondary"
                        android:clickable="true"
                        android:focusable="true"
                        android:gravity="center"
                        android:text="@string/settings_target_reset"
                        android:textColor="#007AFF"
                        android:textSize="13sp"
                        android:textStyle="bold" />
                </LinearLayout>

            </LinearLayout>

        </androidx.cardview.widget.CardView>

        <!-- Theme Options -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/settings_theme_section"
            android:textColor="#007AFF"
            android:textSize="13sp"
            android:textStyle="bold" />

        <androidx.cardview.widget.CardView
            style="@style/Widget.GlassCard"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            app:cardBackgroundColor="@color/transparent"
            app:cardElevation="6dp">

            <RadioGroup
                android:id="@+id/rg_theme"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_liquid_glass_card"
                android:padding="12dp">

                <RadioButton
                    android:id="@+id/rb_theme_light"
                    android:layout_width="match_parent"
                    android:layout_height="44dp"
                    android:text="@string/settings_theme_light"
                    android:textColor="?attr/colorOnBackground"
                    android:textSize="14sp" />

                <RadioButton
                    android:id="@+id/rb_theme_dark"
                    android:layout_width="match_parent"
                    android:layout_height="44dp"
                    android:text="@string/settings_theme_dark"
                    android:textColor="?attr/colorOnBackground"
                    android:textSize="14sp" />

                <RadioButton
                    android:id="@+id/rb_theme_system"
                    android:layout_width="match_parent"
                    android:layout_height="44dp"
                    android:text="@string/settings_theme_system"
                    android:textColor="?attr/colorOnBackground"
                    android:textSize="14sp" />

            </RadioGroup>

        </androidx.cardview.widget.CardView>

        <!-- Data Management -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/settings_data_section"
            android:textColor="#FF2D55"
            android:textSize="13sp"
            android:textStyle="bold" />

        <androidx.cardview.widget.CardView
            style="@style/Widget.GlassCard"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            app:cardBackgroundColor="@color/transparent"
            app:cardElevation="6dp">

            <LinearLayout
                android:id="@+id/btn_clear_favorites"
                android:layout_width="match_parent"
                android:layout_height="52dp"
                android:background="@drawable/bg_liquid_glass_card"
                android:clickable="true"
                android:focusable="true"
                android:gravity="center_vertical"
                android:orientation="horizontal"
                android:paddingStart="16dp"
                android:paddingEnd="16dp">

                <ImageView
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:contentDescription="Delete"
                    android:src="@drawable/ic_delete"
                    app:tint="#FF2D55" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="12dp"
                    android:text="@string/settings_clear_favorites"
                    android:textColor="#FF2D55"
                    android:textSize="15sp"
                    android:textStyle="bold" />
            </LinearLayout>

        </androidx.cardview.widget.CardView>

        <!-- About App -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/settings_about_section"
            android:textColor="#007AFF"
            android:textSize="13sp"
            android:textStyle="bold" />

        <androidx.cardview.widget.CardView
            style="@style/Widget.GlassCard"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            app:cardBackgroundColor="@color/transparent"
            app:cardElevation="6dp">

            <LinearLayout
                android:id="@+id/card_settings_about"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_liquid_glass_card"
                android:orientation="vertical"
                android:padding="16dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:gravity="center_vertical"
                    android:orientation="horizontal">

                    <ImageView
                        android:layout_width="24dp"
                        android:layout_height="24dp"
                        android:contentDescription="Info"
                        android:src="@drawable/ic_info"
                        app:tint="#007AFF" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="8dp"
                        android:text="@string/app_name"
                        android:textColor="?attr/colorOnBackground"
                        android:textSize="16sp"
                        android:textStyle="bold" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:lineSpacingExtra="4dp"
                    android:text="@string/settings_about_app_desc"
                    android:textColor="#6E6E73"
                    android:textSize="13sp" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    android:text="@string/settings_version"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

            </LinearLayout>

        </androidx.cardview.widget.CardView>

    </LinearLayout>

</ScrollView>
"""

# 5. item_favorite_card.xml
item_favorite_card_xml = """<?xml version="1.0" encoding="utf-8"?>
<androidx.cardview.widget.CardView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    style="@style/Widget.GlassCard"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_marginBottom="12dp"
    app:cardBackgroundColor="@color/transparent"
    app:cardElevation="6dp">

    <LinearLayout
        android:id="@+id/card_item_inner"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@drawable/bg_liquid_glass_card"
        android:orientation="vertical"
        android:padding="18dp">

        <TextView
            android:id="@+id/tv_item_text"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:lineSpacingExtra="6dp"
            android:text="夸奖内容..."
            android:textColor="?attr/colorOnBackground"
            android:textSize="15sp"
            android:textStyle="bold" />

        <RelativeLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="14dp">

            <TextView
                android:id="@+id/tv_item_date"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentStart="true"
                android:layout_centerVertical="true"
                android:text="2026.11.08"
                android:textColor="#6E6E73"
                android:textSize="11sp" />

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentEnd="true"
                android:orientation="horizontal">

                <ImageView
                    android:id="@+id/btn_item_copy"
                    android:layout_width="32dp"
                    android:layout_height="32dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:contentDescription="@string/btn_copy"
                    android:padding="7dp"
                    android:src="@drawable/ic_copy"
                    app:tint="#007AFF" />

                <ImageView
                    android:id="@+id/btn_item_share"
                    android:layout_width="32dp"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:contentDescription="@string/btn_share"
                    android:padding="7dp"
                    android:src="@drawable/ic_share"
                    app:tint="#007AFF" />

                <ImageView
                    android:id="@+id/btn_item_delete"
                    android:layout_width="32dp"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:contentDescription="Delete"
                    android:padding="7dp"
                    android:src="@drawable/ic_delete"
                    app:tint="#FF2D55" />

            </LinearLayout>

        </RelativeLayout>

    </LinearLayout>

</androidx.cardview.widget.CardView>
"""

layouts = {
    "activity_main.xml": activity_main_xml,
    "layout_tab_praise.xml": layout_tab_praise_xml,
    "layout_tab_favorites.xml": layout_tab_favorites_xml,
    "layout_tab_settings.xml": layout_tab_settings_xml,
    "item_favorite_card.xml": item_favorite_card_xml
}

for filename, content in layouts.items():
    with open(f"{project_dir}/app/src/main/res/layout/{filename}", "w", encoding="utf-8") as f:
        f.write(content)

print("All XML layouts refactored.")
