import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Redesign drawables to eliminate ugly black shadows and ensure crisp contrast
bg_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#F1F5F9"
        android:centerColor="#E2E8F0"
        android:endColor="#F8FAFC"
        android:type="linear" />
</shape>
"""

bg_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#090D16"
        android:centerColor="#111827"
        android:endColor="#1E293B"
        android:type="linear" />
</shape>
"""

# Frosted Glass Card Light Mode (No harsh shadow, clean subtle stroke)
bg_glass_card_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#F2FFFFFF" />
    <stroke
        android:width="1.5dp"
        android:color="#E2E8F0" />
</shape>
"""

# Frosted Glass Card Dark Mode
bg_glass_card_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#20FFFFFF" />
    <stroke
        android:width="1.5dp"
        android:color="#33FFFFFF" />
</shape>
"""

# Floating Nav Capsule Light Mode
bg_nav_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <solid android:color="#FAFFFFFF" />
    <stroke
        android:width="1.5dp"
        android:color="#CBD5E1" />
</shape>
"""

# Floating Nav Capsule Dark Mode
bg_nav_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <solid android:color="#CC1E293B" />
    <stroke
        android:width="1.5dp"
        android:color="#475569" />
</shape>
"""

# Nav Selected Pill Light Mode
bg_nav_selected_light = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#007AFF" />
</shape>
"""

# Nav Selected Pill Dark Mode
bg_nav_selected_dark = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <solid android:color="#0A84FF" />
</shape>
"""

# Primary Glass Action Button
bg_glass_button = """<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#30FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="24dp" />
            <solid android:color="#007AFF" />
        </shape>
    </item>
</ripple>
"""

# Secondary Glass Button
bg_glass_button_secondary = """<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#15007AFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <solid android:color="#0F007AFF" />
            <stroke
                android:width="1dp"
                android:color="#20007AFF" />
        </shape>
    </item>
</ripple>
"""

# Input Box
bg_glass_input = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="16dp" />
    <solid android:color="#0A000000" />
    <stroke
        android:width="1dp"
        android:color="#20000000" />
</shape>
"""

drawables = {
    "bg_dynamic_gradient_light.xml": bg_light,
    "bg_dynamic_gradient_dark.xml": bg_dark,
    "bg_liquid_glass_card.xml": bg_glass_card_light,
    "bg_liquid_glass_card_dark.xml": bg_glass_card_dark,
    "bg_liquid_glass_nav.xml": bg_nav_light,
    "bg_liquid_glass_nav_dark.xml": bg_nav_dark,
    "bg_nav_item_selected.xml": bg_nav_selected_light,
    "bg_nav_item_selected_dark.xml": bg_nav_selected_dark,
    "bg_glass_button.xml": bg_glass_button,
    "bg_glass_button_secondary.xml": bg_glass_button_secondary,
    "bg_glass_input.xml": bg_glass_input
}

for filename, content in drawables.items():
    with open(f"{project_dir}/app/src/main/res/drawable/{filename}", "w", encoding="utf-8") as f:
        f.write(content)

print("Drawables updated successfully.")
