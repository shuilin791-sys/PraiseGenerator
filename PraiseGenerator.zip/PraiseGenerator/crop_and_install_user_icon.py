import os
from PIL import Image

src_img_path = "/working_dir/c_22b5dd38ba53a246/user_uploaded_files/ttl=63d/user_uploaded/1000111449.jpg"
project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
res_dir = f"{project_dir}/app/src/main/res"

img = Image.open(src_img_path).convert("RGBA")
width, height = img.size

# Find non-black bounding box
# Threshold to detect black outer background
bbox = None
# Inspect pixels to find the bounding box of the icon
gray = img.convert("L")
# Bounding box of pixels with brightness > 15
bbox = gray.point(lambda p: 255 if p > 15 else 0).getbbox()

if bbox:
    cropped_img = img.crop(bbox)
    print(f"Original size: {img.size}, Cropped bounding box: {bbox}, New size: {cropped_img.size}")
else:
    cropped_img = img

# Save cropped PNG deliverable for user preview
output_dir = "/working_dir/c_22b5dd38ba53a246/artifacts/file_generation/ttl=63d/output"
os.makedirs(output_dir, exist_ok=True)
cropped_png_path = os.path.join(output_dir, "cropped_app_icon.png")
cropped_img.save(cropped_png_path, "PNG")

# Generate all mipmap launcher icon sizes
sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192
}

for folder, sz in sizes.items():
    folder_path = os.path.join(res_dir, folder)
    os.makedirs(folder_path, exist_ok=True)
    
    resized_img = cropped_img.resize((sz, sz), Image.Resampling.LANCZOS)
    resized_img.save(os.path.join(folder_path, "ic_launcher.png"), "PNG")
    resized_img.save(os.path.join(folder_path, "ic_launcher_round.png"), "PNG")

# Also copy to drawable/ic_launcher.png
drawable_dir = os.path.join(res_dir, "drawable")
os.makedirs(drawable_dir, exist_ok=True)
cropped_img.resize((192, 192), Image.Resampling.LANCZOS).save(os.path.join(drawable_dir, "ic_launcher.png"), "PNG")

print("User icon cropped and installed into project resources successfully.")
