import os
from PIL import Image

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
src_img_path = "/working_dir/c_22b5dd38ba53a246/user_uploaded_files/ttl=63d/tool_generated/watermarked_img_13076184785813497663.jpg"

res_dir = f"{project_dir}/app/src/main/res"

# Icon density sizes
sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192
}

img = Image.open(src_img_path).convert("RGBA")

for folder, sz in sizes.items():
    folder_path = os.path.join(res_dir, folder)
    os.makedirs(folder_path, exist_ok=True)
    
    resized_img = img.resize((sz, sz), Image.Resampling.LANCZOS)
    resized_img.save(os.path.join(folder_path, "ic_launcher.png"), "PNG")
    resized_img.save(os.path.join(folder_path, "ic_launcher_round.png"), "PNG")

# Also copy to drawable/ic_launcher.png
drawable_dir = os.path.join(res_dir, "drawable")
os.makedirs(drawable_dir, exist_ok=True)
img.resize((192, 192), Image.Resampling.LANCZOS).save(os.path.join(drawable_dir, "ic_launcher.png"), "PNG")

# Update AndroidManifest.xml to point icon to @mipmap/ic_launcher
manifest_file = f"{project_dir}/app/src/main/AndroidManifest.xml"
with open(manifest_file, "r", encoding="utf-8") as f:
    m_code = f.read()

m_code = m_code.replace('android:icon="@drawable/ic_tab_praise"', 'android:icon="@mipmap/ic_launcher"')
m_code = m_code.replace('android:roundIcon="@drawable/ic_tab_praise"', 'android:roundIcon="@mipmap/ic_launcher_round"')

with open(manifest_file, "w", encoding="utf-8") as f:
    f.write(m_code)

print("App launcher icons generated and installed into project resources successfully.")
