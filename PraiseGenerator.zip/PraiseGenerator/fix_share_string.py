file_path = "app/src/main/java/com/yangxinning/praise/MainActivity.java"

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# Replace the literal newline string with properly escaped \n
old_part = 'String shareContent = "【Yang Xinning 专属夸奖】\n" + text + "\n\n—— 来自 Yang Xinning 夸夸生成器 Liquid Glass App";'

fixed_code = 'String shareContent = "【Yang Xinning 专属夸奖】\\n" + text + "\\n\\n—— 来自 Yang Xinning 夸夸生成器 Liquid Glass App";'

if 'String shareContent =' in content:
    lines = content.splitlines()
    new_lines = []
    skip = False
    for line in lines:
        if 'String shareContent =' in line:
            new_lines.append('        ' + fixed_code)
            skip = True
        elif skip and 'shareIntent.putExtra' in line:
            skip = False
            new_lines.append(line)
        elif not skip:
            new_lines.append(line)
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(new_lines) + "\n")

print("MainActivity.java string literal fixed.")
