import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update PraiseItem to be 100% safe against String.format errors
praise_item_code = """package com.yangxinning.praise.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PraiseItem implements Serializable {
    private String id;
    private String rawQuote;
    private String formattedText;
    private long timestamp;
    private String targetName;

    public PraiseItem() {
    }

    public PraiseItem(String id, String rawQuote, String targetName) {
        this.id = id;
        this.rawQuote = rawQuote;
        this.targetName = (targetName != null && !targetName.trim().isEmpty()) ? targetName.trim() : "Yang Xinning";
        this.timestamp = System.currentTimeMillis();
        this.formattedText = safeFormat(rawQuote, this.targetName);
    }

    private String safeFormat(String quote, String name) {
        if (quote == null) return "";
        try {
            if (quote.contains("%s")) {
                return String.format(quote, name);
            } else {
                return quote;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return quote.replace("%s", name);
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRawQuote() {
        return rawQuote;
    }

    public void setRawQuote(String rawQuote) {
        this.rawQuote = rawQuote;
    }

    public String getFormattedText() {
        if (formattedText == null || formattedText.isEmpty()) {
            return safeFormat(rawQuote, targetName != null ? targetName : "Yang Xinning");
        }
        return formattedText;
    }

    public void setFormattedText(String formattedText) {
        this.formattedText = formattedText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
        this.formattedText = safeFormat(rawQuote, targetName);
    }

    public String getFormattedDate() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        } catch (Exception e) {
            return "";
        }
    }
}
"""

with open(f"{package_path}/model/PraiseItem.java", "w", encoding="utf-8") as f:
    f.write(praise_item_code)

# 2. Update MainActivity.java to use crash-proof ViewPropertyAnimator and try-catch safety wrapper
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    content = f.read()

# Replace generateNewCompliment with crash-proof ViewPropertyAnimator
old_gen = """    private void generateNewCompliment(boolean animate) {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);

        if (animate && cardComplimentWrapper != null) {
            cardComplimentWrapper.clearAnimation();
            Animation popAnim = AnimationUtils.loadAnimation(this, R.anim.card_pop);
            cardComplimentWrapper.startAnimation(popAnim);
        }

        tvComplimentContent.setText(currentPraiseItem.getFormattedText());
        updateFavoriteButtonState();
    }"""

new_gen = """    private void generateNewCompliment(boolean animate) {
        try {
            String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
            if (tvTargetName != null) {
                tvTargetName.setText(targetName);
            }

            currentPraiseItem = PraiseManager.getInstance().generateRandomPraise(targetName);
            if (currentPraiseItem == null) return;

            if (tvComplimentContent != null) {
                tvComplimentContent.setText(currentPraiseItem.getFormattedText());
                if (animate) {
                    tvComplimentContent.setAlpha(0.3f);
                    tvComplimentContent.animate()
                            .alpha(1.0f)
                            .setDuration(200)
                            .start();
                }
            }

            updateFavoriteButtonState();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }"""

content = content.replace(old_gen, new_gen)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(content)

print("PraiseItem and MainActivity updated with bulletproof crash prevention.")
