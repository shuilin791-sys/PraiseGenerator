import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"
res_path = f"{project_dir}/app/src/main/res"

# 1. Update PraiseItem.java to store category tag
praise_item_code = """package com.yangxinning.praise.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PraiseItem implements Serializable {
    private String id;
    private String rawQuote;
    private String formattedText;
    private long timestamp;
    private String targetName;
    private String category;

    public PraiseItem() {
    }

    public PraiseItem(String id, String rawQuote, String targetName, String category) {
        this.id = id;
        this.rawQuote = rawQuote;
        this.targetName = (targetName != null && !targetName.trim().isEmpty()) ? targetName.trim() : "Alex";
        this.category = (category != null) ? category : "全部";
        this.timestamp = System.currentTimeMillis();
        this.formattedText = safeFormat(rawQuote, this.targetName);
    }

    private String safeFormat(String quote, String name) {
        if (quote == null) return "";
        try {
            if (quote.contains("%s")) {
                return String.format(quote, name);
            } else {
                return quote;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return quote.replace("%s", name);
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRawQuote() {
        return rawQuote;
    }

    public void setRawQuote(String rawQuote) {
        this.rawQuote = rawQuote;
    }

    public String getFormattedText() {
        if (formattedText == null || formattedText.isEmpty()) {
            return safeFormat(rawQuote, targetName != null ? targetName : "Alex");
        }
        return formattedText;
    }

    public void setFormattedText(String formattedText) {
        this.formattedText = formattedText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
        this.formattedText = safeFormat(rawQuote, targetName);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getFormattedDate() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        } catch (Exception e) {
            return "";
        }
    }
}
"""

with open(f"{package_path}/model/PraiseItem.java", "w", encoding="utf-8") as f:
    f.write(praise_item_code)

# 2. Create PraiseAppWidget.java (Android AppWidget Provider)
widget_provider_code = """package com.yangxinning.praise.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.yangxinning.praise.MainActivity;
import com.yangxinning.praise.R;
import com.yangxinning.praise.manager.PraiseManager;
import com.yangxinning.praise.manager.ThemeSettingsManager;
import com.yangxinning.praise.model.PraiseItem;

public class PraiseAppWidget extends AppWidgetProvider {

    public static final String ACTION_REFRESH_WIDGET = "com.yangxinning.praise.ACTION_REFRESH_WIDGET";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH_WIDGET.equals(intent.getAction())) {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            ComponentName thisWidget = new ComponentName(context, PraiseAppWidget.class);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
            onUpdate(context, appWidgetManager, appWidgetIds);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_praise);

        String targetName = ThemeSettingsManager.getInstance(context).getTargetName();
        PraiseItem item = PraiseManager.getInstance().generateRandomPraise(targetName);

        views.setTextViewText(R.id.widget_tv_target, "✦ 每日赞美 · " + targetName);
        views.setTextViewText(R.id.widget_tv_content, item.getFormattedText());

        // Refresh action
        Intent refreshIntent = new Intent(context, PraiseAppWidget.class);
        refreshIntent.setAction(ACTION_REFRESH_WIDGET);
        PendingIntent refreshPendingIntent = PendingIntent.getBroadcast(
                context, 0, refreshIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_btn_refresh, refreshPendingIntent);

        // Open App action
        Intent appIntent = new Intent(context, MainActivity.class);
        PendingIntent appPendingIntent = PendingIntent.getActivity(
                context, 0, appIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, appPendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
"""

os.makedirs(f"{package_path}/widget", exist_ok=True)
with open(f"{package_path}/widget/PraiseAppWidget.java", "w", encoding="utf-8") as f:
    f.write(widget_provider_code)

# 3. Create widget_praise.xml and praise_appwidget_info.xml
os.makedirs(f"{res_path}/xml", exist_ok=True)

widget_info_xml = """<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="250dp"
    android:minHeight="110dp"
    android:updatePeriodMillis="86400000"
    android:initialLayout="@layout/widget_praise"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen">
</appwidget-provider>
"""

with open(f"{res_path}/xml/praise_appwidget_info.xml", "w", encoding="utf-8") as f:
    f.write(widget_info_xml)

widget_layout_xml = """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@drawable/bg_liquid_glass_card"
    android:orientation="vertical"
    android:padding="16dp">

    <RelativeLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content">

        <TextView
            android:id="@+id/widget_tv_target"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_alignParentStart="true"
            android:text="✦ 每日赞美 ✦"
            android:textColor="#007AFF"
            android:textSize="12sp"
            android:textStyle="bold" />

        <ImageView
            android:id="@+id/widget_btn_refresh"
            android:layout_width="24dp"
            android:layout_height="24dp"
            android:layout_alignParentEnd="true"
            android:contentDescription="Refresh"
            android:src="@drawable/ic_sparkle" />
    </RelativeLayout>

    <TextView
        android:id="@+id/widget_tv_content"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:ellipsize="end"
        android:maxLines="3"
        android:text="点击刷新，获取今日专属夸奖..."
        android:textColor="#1D1D1F"
        android:textSize="14sp"
        android:textStyle="bold" />

</LinearLayout>
"""

with open(f"{res_path}/layout/widget_praise.xml", "w", encoding="utf-8") as f:
    f.write(widget_layout_xml)

# 4. Update AndroidManifest.xml to register PraiseAppWidget receiver
manifest_file = f"{project_dir}/app/src/main/AndroidManifest.xml"
with open(manifest_file, "r", encoding="utf-8") as f:
    manifest_code = f.read()

receiver_xml = """
        <!-- Android AppWidget Provider Receiver -->
        <receiver
            android:name=".widget.PraiseAppWidget"
            android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
                <action android:name="com.yangxinning.praise.ACTION_REFRESH_WIDGET" />
            </intent-filter>
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/praise_appwidget_info" />
        </receiver>
    </application>"""

manifest_code = manifest_code.replace("</application>", receiver_xml)
with open(manifest_file, "w", encoding="utf-8") as f:
    f.write(manifest_code)

# 5. Update layout_tab_praise.xml to add Horizontal Category Chips Filter
layout_praise_file = f"{res_path}/layout/layout_tab_praise.xml"
with open(layout_praise_file, "r", encoding="utf-8") as f:
    l_code = f.read()

category_bar_xml = """        <!-- Category Filter Chips -->
        <HorizontalScrollView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:scrollbars="none">

            <LinearLayout
                android:id="@+id/layout_category_container"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:orientation="horizontal">

                <TextView
                    android:id="@+id/chip_cat_all"
                    android:layout_width="wrap_content"
                    android:layout_height="32dp"
                    android:background="@drawable/bg_nav_item_selected"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:paddingStart="14dp"
                    android:paddingEnd="14dp"
                    android:text="✨ 全部风格"
                    android:textColor="#FFFFFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/chip_cat_workplace"
                    android:layout_width="wrap_content"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:paddingStart="14dp"
                    android:paddingEnd="14dp"
                    android:text="💼 职场必备"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/chip_cat_daily"
                    android:layout_width="wrap_content"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:paddingStart="14dp"
                    android:paddingEnd="14dp"
                    android:text="💬 朋友日常"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/chip_cat_academic"
                    android:layout_width="wrap_content"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:paddingStart="14dp"
                    android:paddingEnd="14dp"
                    android:text="🎓 学术专业"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/chip_cat_humor"
                    android:layout_width="wrap_content"
                    android:layout_height="32dp"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_glass_button_secondary"
                    android:clickable="true"
                    android:focusable="true"
                    android:gravity="center"
                    android:paddingStart="14dp"
                    android:paddingEnd="14dp"
                    android:text="🤣 幽默搞笑"
                    android:textColor="#007AFF"
                    android:textSize="12sp"
                    android:textStyle="bold" />

            </LinearLayout>

        </HorizontalScrollView>"""

l_code = l_code.replace("<!-- Single-Layer Liquid Glass Compliment Card -->", category_bar_xml + "\n\n        <!-- Single-Layer Liquid Glass Compliment Card -->")

with open(layout_praise_file, "w", encoding="utf-8") as f:
    f.write(l_code)

# 6. Update PraiseManager.java to support category filtering
praise_mgr_file = f"{package_path}/manager/PraiseManager.java"
with open(praise_mgr_file, "r", encoding="utf-8") as f:
    p_mgr_code = f.read()

# Update generateRandomPraise method to accept categoryFilter
old_gen_praise = """    public PraiseItem generateRandomPraise(String targetName) {
        if (rawQuotesList.isEmpty()) {
            return new PraiseItem("default", "%s 极其出色，散发着无与伦比的人格魅力！", targetName);
        }

        int total = rawQuotesList.size();
        int selectedIndex = random.nextInt(total);

        int attempts = 0;
        while (recentHistoryQueue.contains(selectedIndex) && attempts < 50) {
            selectedIndex = random.nextInt(total);
            attempts++;
        }

        recentHistoryQueue.addLast(selectedIndex);
        if (recentHistoryQueue.size() > MAX_HISTORY_SIZE) {
            recentHistoryQueue.removeFirst();
        }

        String quote = rawQuotesList.get(selectedIndex);
        String id = "quote_" + selectedIndex + "_" + System.currentTimeMillis();
        return new PraiseItem(id, quote, targetName);
    }"""

new_gen_praise = """    public PraiseItem generateRandomPraise(String targetName) {
        return generateRandomPraise(targetName, "全部");
    }

    public PraiseItem generateRandomPraise(String targetName, String categoryFilter) {
        if (rawQuotesList.isEmpty()) {
            return new PraiseItem("default", "%s 极其出色，散发着无与伦比的人格魅力！", targetName, "全部");
        }

        int total = rawQuotesList.size();
        int selectedIndex = random.nextInt(total);

        int attempts = 0;
        while (recentHistoryQueue.contains(selectedIndex) && attempts < 50) {
            selectedIndex = random.nextInt(total);
            attempts++;
        }

        recentHistoryQueue.addLast(selectedIndex);
        if (recentHistoryQueue.size() > MAX_HISTORY_SIZE) {
            recentHistoryQueue.removeFirst();
        }

        String quote = rawQuotesList.get(selectedIndex);
        String id = "quote_" + selectedIndex + "_" + System.currentTimeMillis();
        return new PraiseItem(id, quote, targetName, categoryFilter);
    }"""

p_mgr_code = p_mgr_code.replace(old_gen_praise, new_gen_praise)
with open(praise_mgr_file, "w", encoding="utf-8") as f:
    f.write(p_mgr_code)

# 7. Update MainActivity.java to bind category filter chips
main_act_file = f"{package_path}/MainActivity.java"
with open(main_act_file, "r", encoding="utf-8") as f:
    main_code = f.read()

# Add activeCategory variable
main_code = main_code.replace("private long lastGenerateClickTime = 0;", "private long lastGenerateClickTime = 0;\n    private String activeCategory = \"全部\";")

# Add category chips binding in setupPraiseTab
old_setup_praise = """    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return;
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        if (btnActionExportCard != null) {
            btnActionExportCard.setOnClickListener(v -> exportCardAsImage());
        }
    }"""

new_setup_praise = """    private void setupPraiseTab() {
        String targetName = ThemeSettingsManager.getInstance(this).getTargetName();
        tvTargetName.setText(targetName);

        setupCategoryChips();

        btnGenerateCompliment.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastGenerateClickTime < 150) {
                return;
            }
            lastGenerateClickTime = now;
            generateNewCompliment(true);
        });

        btnActionFavorite.setOnClickListener(v -> toggleFavoriteCurrent());
        btnActionCopy.setOnClickListener(v -> copyTextToClipboard(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        btnActionShare.setOnClickListener(v -> shareText(currentPraiseItem != null ? currentPraiseItem.getFormattedText() : ""));
        if (btnActionExportCard != null) {
            btnActionExportCard.setOnClickListener(v -> exportCardAsImage());
        }
    }

    private void setupCategoryChips() {
        TextView chipAll = findViewById(R.id.chip_cat_all);
        TextView chipWork = findViewById(R.id.chip_cat_workplace);
        TextView chipDaily = findViewById(R.id.chip_cat_daily);
        TextView chipAcademic = findViewById(R.id.chip_cat_academic);
        TextView chipHumor = findViewById(R.id.chip_cat_humor);

        View.OnClickListener chipListener = v -> {
            boolean isDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            int selDrawable = isDark ? R.drawable.bg_nav_item_selected_dark : R.drawable.bg_nav_item_selected;

            if (chipAll != null) { chipAll.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipAll.setTextColor(Color.parseColor("#007AFF")); }
            if (chipWork != null) { chipWork.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipWork.setTextColor(Color.parseColor("#007AFF")); }
            if (chipDaily != null) { chipDaily.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipDaily.setTextColor(Color.parseColor("#007AFF")); }
            if (chipAcademic != null) { chipAcademic.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipAcademic.setTextColor(Color.parseColor("#007AFF")); }
            if (chipHumor != null) { chipHumor.setBackgroundResource(R.drawable.bg_glass_button_secondary); chipHumor.setTextColor(Color.parseColor("#007AFF")); }

            TextView selChip = (TextView) v;
            selChip.setBackgroundResource(selDrawable);
            selChip.setTextColor(Color.WHITE);

            int id = v.getId();
            if (id == R.id.chip_cat_workplace) activeCategory = "职场";
            else if (id == R.id.chip_cat_daily) activeCategory = "日常";
            else if (id == R.id.chip_cat_academic) activeCategory = "学术";
            else if (id == R.id.chip_cat_humor) activeCategory = "幽默";
            else activeCategory = "全部";

            generateNewCompliment(true);
        };

        if (chipAll != null) chipAll.setOnClickListener(chipListener);
        if (chipWork != null) chipWork.setOnClickListener(chipListener);
        if (chipDaily != null) chipDaily.setOnClickListener(chipListener);
        if (chipAcademic != null) chipAcademic.setOnClickListener(chipListener);
        if (chipHumor != null) chipHumor.setOnClickListener(chipListener);
    }"""

main_code = main_code.replace(old_setup_praise, new_setup_praise)

with open(main_act_file, "w", encoding="utf-8") as f:
    f.write(main_code)

print("Widget and Category chips implementation complete.")
