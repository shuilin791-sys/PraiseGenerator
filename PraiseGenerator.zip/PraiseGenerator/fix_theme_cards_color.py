import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update layout_tab_settings.xml to add ID for theme card
layout_settings_file = f"{project_dir}/app/src/main/res/layout/layout_tab_settings.xml"
with open(layout_settings_file, "r", encoding="utf-8") as f:
    settings_xml = f.read()

# Add ID android:id="@+id/card_settings_theme" to the theme RadioGroup container
old_theme_container = """        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:background="@drawable/bg_liquid_glass_card"
            android:orientation="vertical">

            <RadioGroup
                android:id="@+id/rg_theme"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:padding="12dp">"""

new_theme_container = """        <LinearLayout
            android:id="@+id/card_settings_theme"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:background="@drawable/bg_liquid_glass_card"
            android:orientation="vertical">

            <RadioGroup
                android:id="@+id/rg_theme"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:padding="12dp">"""

settings_xml = settings_xml.replace(old_theme_container, new_theme_container)

with open(layout_settings_file, "w", encoding="utf-8") as f:
    f.write(settings_xml)

# 2. Update MainActivity.java to apply dark/light card background to ALL cards in Settings & Main
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    content = f.read()

old_update_ui = """        int cardRes = isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card;

        if (cardComplimentWrapper != null) cardComplimentWrapper.setBackgroundResource(cardRes);

        View cardTarget = findViewById(R.id.card_settings_target);
        if (cardTarget != null) cardTarget.setBackgroundResource(cardRes);

        View cardAbout = findViewById(R.id.card_settings_about);
        if (cardAbout != null) cardAbout.setBackgroundResource(cardRes);"""

new_update_ui = """        int cardRes = isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card;

        if (cardComplimentWrapper != null) cardComplimentWrapper.setBackgroundResource(cardRes);

        View cardTarget = findViewById(R.id.card_settings_target);
        if (cardTarget != null) cardTarget.setBackgroundResource(cardRes);

        View cardTheme = findViewById(R.id.card_settings_theme);
        if (cardTheme != null) cardTheme.setBackgroundResource(cardRes);

        View cardClear = findViewById(R.id.btn_clear_favorites);
        if (cardClear != null) cardClear.setBackgroundResource(cardRes);

        View cardAbout = findViewById(R.id.card_settings_about);
        if (cardAbout != null) cardAbout.setBackgroundResource(cardRes);

        // Update RadioButton text colors for high contrast
        int textColor = isDark ? Color.parseColor("#F5F5F7") : Color.parseColor("#1D1D1F");
        if (rbThemeLight != null) rbThemeLight.setTextColor(textColor);
        if (rbThemeDark != null) rbThemeDark.setTextColor(textColor);
        if (rbThemeSystem != null) rbThemeSystem.setTextColor(textColor);"""

content = content.replace(old_update_ui, new_update_ui)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(content)

print("Theme settings cards & radio text colors updated for complete dark mode consistency.")
