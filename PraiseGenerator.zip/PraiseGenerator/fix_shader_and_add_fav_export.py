import os

project_dir = "/working_dir/c_22b5dd38ba53a246/YangXinningPraiseApp"
package_path = f"{project_dir}/app/src/main/java/com/yangxinning/praise"

# 1. Update item_favorite_card.xml: Add Export Card button in Favorites list items
item_card_file = f"{project_dir}/app/src/main/res/layout/item_favorite_card.xml"
item_card_xml = """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/card_item_inner"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_marginBottom="12dp"
    android:background="@drawable/bg_liquid_glass_card"
    android:orientation="vertical"
    android:padding="18dp">

    <TextView
        android:id="@+id/tv_item_text"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:lineSpacingExtra="6dp"
        android:text="夸奖内容..."
        android:textColor="?attr/colorOnBackground"
        android:textSize="15sp"
        android:textStyle="bold" />

    <RelativeLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="14dp">

        <TextView
            android:id="@+id/tv_item_date"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_alignParentStart="true"
            android:layout_centerVertical="true"
            android:text="2026.11.08"
            android:textColor="#6E6E73"
            android:textSize="11sp" />

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_alignParentEnd="true"
            android:orientation="horizontal">

            <ImageView
                android:id="@+id/btn_item_export_card"
                android:layout_width="32dp"
                android:layout_height="32dp"
                android:background="@drawable/bg_glass_button_secondary"
                android:contentDescription="@string/btn_export_card"
                android:padding="7dp"
                android:src="@drawable/ic_sparkle"
                app:tint="#007AFF" />

            <ImageView
                android:id="@+id/btn_item_copy"
                android:layout_width="32dp"
                android:layout_height="32dp"
                android:layout_marginStart="8dp"
                android:background="@drawable/bg_glass_button_secondary"
                android:contentDescription="@string/btn_copy"
                android:padding="7dp"
                android:src="@drawable/ic_copy"
                app:tint="#007AFF" />

            <ImageView
                android:id="@+id/btn_item_share"
                android:layout_width="32dp"
                android:layout_height="32dp"
                android:layout_marginStart="8dp"
                android:background="@drawable/bg_glass_button_secondary"
                android:contentDescription="@string/btn_share"
                android:padding="7dp"
                android:src="@drawable/ic_share"
                app:tint="#007AFF" />

            <ImageView
                android:id="@+id/btn_item_delete"
                android:layout_width="32dp"
                android:layout_height="32dp"
                android:layout_marginStart="8dp"
                android:background="@drawable/bg_glass_button_secondary"
                android:contentDescription="Delete"
                android:padding="7dp"
                android:src="@drawable/ic_delete"
                app:tint="#FF2D55" />

        </LinearLayout>

    </RelativeLayout>

</LinearLayout>
"""

with open(item_card_file, "w", encoding="utf-8") as f:
    f.write(item_card_xml)

# 2. Update FavoritesAdapter.java: Add onExportCard to OnItemActionListener
adapter_java = """package com.yangxinning.praise.adapter;

import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yangxinning.praise.R;
import com.yangxinning.praise.model.PraiseItem;

import java.util.ArrayList;
import java.util.List;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder> {

    public interface OnItemActionListener {
        void onCopy(PraiseItem item);
        void onShare(PraiseItem item);
        void onDelete(PraiseItem item, int position);
        void onExportCard(PraiseItem item);
    }

    private final List<PraiseItem> itemList;
    private final OnItemActionListener listener;

    public FavoritesAdapter(List<PraiseItem> list, OnItemActionListener listener) {
        this.itemList = (list != null) ? list : new ArrayList<>();
        this.listener = listener;
    }

    public void updateData(List<PraiseItem> newList) {
        this.itemList.clear();
        if (newList != null) {
            this.itemList.addAll(newList);
        }
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (position >= 0 && position < itemList.size()) {
            itemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, itemList.size() - position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_favorite_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PraiseItem item = itemList.get(position);
        holder.tvText.setText(item.getFormattedText());
        holder.tvDate.setText(item.getFormattedDate());

        boolean isDark = (holder.itemView.getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (holder.cardInner != null) {
            holder.cardInner.setBackgroundResource(isDark ? R.drawable.bg_liquid_glass_card_dark : R.drawable.bg_liquid_glass_card);
        }

        if (holder.btnExportCard != null) {
            holder.btnExportCard.setOnClickListener(v -> {
                if (listener != null) listener.onExportCard(item);
            });
        }

        holder.btnCopy.setOnClickListener(v -> {
            if (listener != null) listener.onCopy(item);
        });

        holder.btnShare.setOnClickListener(v -> {
            if (listener != null) listener.onShare(item);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(item, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View cardInner;
        TextView tvText;
        TextView tvDate;
        ImageView btnExportCard;
        ImageView btnCopy;
        ImageView btnShare;
        ImageView btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardInner = itemView.findViewById(R.id.card_item_inner);
            tvText = itemView.findViewById(R.id.tv_item_text);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            btnExportCard = itemView.findViewById(R.id.btn_item_export_card);
            btnCopy = itemView.findViewById(R.id.btn_item_copy);
            btnShare = itemView.findViewById(R.id.btn_item_share);
            btnDelete = itemView.findViewById(R.id.btn_item_delete);
        }
    }
}
"""

with open(f"{package_path}/adapter/FavoritesAdapter.java", "w", encoding="utf-8") as f:
    f.write(adapter_java)

# 3. Update MainActivity.java: Add import android.graphics.Shader and handle onExportCard in Favorites tab
main_activity_file = f"{package_path}/MainActivity.java"
with open(main_activity_file, "r", encoding="utf-8") as f:
    m_code = f.read()

# Ensure Shader is imported
if "import android.graphics.Shader;" not in m_code:
    m_code = m_code.replace("import android.graphics.Color;", "import android.graphics.Color;\nimport android.graphics.Shader;")

# Update setupFavoritesTab to handle onExportCard
old_fav_setup = """        favoritesAdapter = new FavoritesAdapter(null, new FavoritesAdapter.OnItemActionListener() {
            @Override
            public void onCopy(PraiseItem item) {
                copyTextToClipboard(item.getFormattedText());
            }

            @Override
            public void onShare(PraiseItem item) {
                shareText(item.getFormattedText());
            }

            @Override
            public void onDelete(PraiseItem item, int position) {
                FavoritesManager.getInstance(MainActivity.this).removeFavorite(item.getId());
                favoritesAdapter.removeItem(position);
                refreshFavoritesHeaderCount();
                updateFavoriteButtonState();
                Toast.makeText(MainActivity.this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
            }
        });"""

new_fav_setup = """        favoritesAdapter = new FavoritesAdapter(null, new FavoritesAdapter.OnItemActionListener() {
            @Override
            public void onCopy(PraiseItem item) {
                copyTextToClipboard(item.getFormattedText());
            }

            @Override
            public void onShare(PraiseItem item) {
                shareText(item.getFormattedText());
            }

            @Override
            public void onDelete(PraiseItem item, int position) {
                FavoritesManager.getInstance(MainActivity.this).removeFavorite(item.getId());
                favoritesAdapter.removeItem(position);
                refreshFavoritesHeaderCount();
                updateFavoriteButtonState();
                Toast.makeText(MainActivity.this, R.string.toast_unfavorited, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onExportCard(PraiseItem item) {
                if (item == null) return;
                try {
                    String targetName = ThemeSettingsManager.getInstance(MainActivity.this).getTargetName();
                    String quoteText = item.getFormattedText();
                    Bitmap cardBitmap = drawBeautifulPraiseCardBitmap(targetName, quoteText);
                    if (cardBitmap != null) {
                        showImagePreviewDialog(cardBitmap);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "卡片生成失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });"""

m_code = m_code.replace(old_fav_setup, new_fav_setup)

with open(main_activity_file, "w", encoding="utf-8") as f:
    f.write(m_code)

print("Shader import added and Favorites tab export card feature implemented successfully.")
